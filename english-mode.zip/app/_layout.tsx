import "../global.css";
import { Stack } from "expo-router";
import { StatusBar } from "expo-status-bar";
import { AppProvider } from "@/src/context/app-context";
import { palette } from "@/src/ui";
import { AppErrorBoundary } from "@/components/app-error-boundary";

export default function RootLayout() {
  return <AppErrorBoundary><AppProvider><StatusBar style="dark" /><Stack screenOptions={{ headerShown: false, contentStyle: { backgroundColor: palette.canvas } }} /></AppProvider></AppErrorBoundary>;
}
