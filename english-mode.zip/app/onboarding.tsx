import AsyncStorage from "@react-native-async-storage/async-storage";
import { router } from "expo-router";
import { useEffect, useMemo, useState } from "react";
import { Pressable, ScrollView, StyleSheet, Text, View } from "react-native";

import { ScreenContainer } from "@/components/screen-container";
import { AnimatedEntrance } from "@/components/animated-entrance";
import { safeGet, safeSet } from "@/src/storage";
import { Body, Eyebrow, palette, PrimaryButton, SecondaryButton, Title } from "@/src/ui";
import { useApp } from "@/src/context/app-context";
import {
  canAdvanceOnboarding,
  DEFAULT_ONBOARDING_DRAFT,
  DURATION_OPTIONS,
  GOAL_OPTIONS,
  INTEREST_OPTIONS,
  LEVEL_OPTIONS,
  normalizeOnboardingDraft,
  ONBOARDING_STEPS,
  profilePatchFromOnboarding,
  type OnboardingDraft,
} from "@/src/onboarding";

const DRAFT_KEY = "english-mode-onboarding-draft-v1";

export default function OnboardingScreen() {
  const { completeOnboarding } = useApp();
  const [draft, setDraft] = useState<OnboardingDraft>(DEFAULT_ONBOARDING_DRAFT);
  const [isLoading, setIsLoading] = useState(true);
  const [isSaving, setIsSaving] = useState(false);
  const [saveMessage, setSaveMessage] = useState("");

  useEffect(() => {
    let active = true;
    void safeGet<unknown>(AsyncStorage, DRAFT_KEY, DEFAULT_ONBOARDING_DRAFT).then((result) => {
      if (!active) return;
      if (result.ok) setDraft(normalizeOnboardingDraft(result.value));
      setIsLoading(false);
    });
    return () => { active = false; };
  }, []);

  const step = draft.step;
  const currentStep = ONBOARDING_STEPS[step];
  const isFinalStep = step === ONBOARDING_STEPS.length - 1;
  const progress = ((step + 1) / ONBOARDING_STEPS.length) * 100;
  const isValid = canAdvanceOnboarding(step, draft);
  const selectedLevel = useMemo(() => LEVEL_OPTIONS.find((option) => option.value === draft.level), [draft.level]);

  const persistDraft = async (next: OnboardingDraft) => {
    setDraft(next);
    const result = await safeSet(AsyncStorage, DRAFT_KEY, next);
    if (!result.ok) setSaveMessage("We’ll keep your choices on this device when storage is available.");
  };

  const updateDraft = (patch: Partial<OnboardingDraft>) => {
    setSaveMessage("");
    void persistDraft({ ...draft, ...patch });
  };

  const finish = async () => {
    if (!isValid || isSaving) return;
    setIsSaving(true);
    setSaveMessage("");
    const result = await safeSet(AsyncStorage, DRAFT_KEY, undefined);
    if (!result.ok) setSaveMessage("Your profile is ready. We’ll finish saving it when storage is available.");
    completeOnboarding(profilePatchFromOnboarding(draft));
    router.replace("/(tabs)" as any);
  };

  const goNext = () => {
    if (!isValid) return;
    if (isFinalStep) { void finish(); return; }
    updateDraft({ step: step + 1 });
  };

  if (isLoading) return <ScreenContainer containerClassName="bg-[#1E2328]" edges={["top", "bottom", "left", "right"]} className="px-6"><View style={styles.loading}><Text style={styles.loadingText}>Preparing your setup…</Text></View></ScreenContainer>;

  return (
    <ScreenContainer containerClassName="bg-[#1E2328]" edges={["top", "bottom", "left", "right"]} className="px-6">
      <ScrollView contentContainerStyle={styles.scrollContent} keyboardShouldPersistTaps="handled">
        <View style={styles.content}>
          <View>
            <View style={styles.topRow}>
              <Eyebrow>{currentStep.eyebrow}</Eyebrow>
              <Text accessibilityLabel={`Setup step ${step + 1} of ${ONBOARDING_STEPS.length}`} style={styles.stepCount}>{step + 1} of {ONBOARDING_STEPS.length}</Text>
            </View>
            <View accessible accessibilityLabel={`Setup progress ${Math.round(progress)} percent`} style={styles.progressTrack}><View style={[styles.progressFill, { width: `${progress}%` }]} /></View>
            <AnimatedEntrance key={currentStep.key}>
              <Title style={styles.title}>{currentStep.title}</Title>
              <Body style={styles.body}>{currentStep.body}</Body>

            {step === 0 && <View style={styles.introCard}><Text style={styles.introMark}>EM</Text><Text style={styles.introTitle}>Short rehearsals. Real situations.</Text><Text style={styles.introBody}>We’ll use your answers to make each speaking session feel relevant from the very first day.</Text></View>}

            {step === 1 && <View style={styles.choices}>{GOAL_OPTIONS.map((item) => <Choice key={item} label={item} selected={draft.goal === item} onPress={() => updateDraft({ goal: item })} />)}</View>}

            {step === 2 && <View style={styles.choices}>{LEVEL_OPTIONS.map((item) => <Choice key={item.value} label={item.value} detail={item.detail} selected={draft.level === item.value} onPress={() => updateDraft({ level: item.value })} />)}</View>}

            {step === 3 && <View><Text style={styles.selectionHint}>{draft.interests.length} of 3 selected</Text><View style={styles.interestGrid}>{INTEREST_OPTIONS.map((item) => { const selected = draft.interests.includes(item); return <Choice key={item} label={item} selected={selected} disabled={!selected && draft.interests.length >= 3} onPress={() => updateDraft({ interests: selected ? draft.interests.filter((interest) => interest !== item) : [...draft.interests, item] })} compact />; })}</View></View>}

            {step === 4 && <View style={styles.choices}>{DURATION_OPTIONS.map((minutes) => <Choice key={minutes} label={`${minutes} minutes`} detail={minutes === 5 ? "A focused daily reset." : minutes === 10 ? "A balanced daily rehearsal." : "A deeper speaking session."} selected={draft.preferredDuration === minutes} onPress={() => updateDraft({ preferredDuration: minutes })} />)}<View style={styles.summary}><Text style={styles.summaryLabel}>YOUR STARTING PLAN</Text><Text style={styles.summaryText}>{draft.goal} · {selectedLevel?.value} · {draft.interests.join(", ")} · {draft.preferredDuration} min/day</Text></View></View>}
            </AnimatedEntrance>
          </View>

          <View style={styles.bottom}>
            {saveMessage ? <Text accessibilityRole="alert" style={styles.saveMessage}>{saveMessage}</Text> : null}
            <View style={styles.dots} accessible accessibilityLabel={`Step ${step + 1} of ${ONBOARDING_STEPS.length}`}><View style={styles.dotGroup}>{ONBOARDING_STEPS.map((item, index) => <View key={item.key} style={[styles.dot, index <= step && styles.dotActive]} />)}</View><Text style={styles.dotCaption}>{isFinalStep ? "Ready when you are" : "You can change this later"}</Text></View>
            <PrimaryButton accessibilityLabel={isFinalStep ? "Create my English Mode profile" : "Continue to the next setup step"} disabled={!isValid || isSaving} onPress={goNext} style={!isValid || isSaving ? styles.disabled : undefined}>{isSaving ? "Saving…" : isFinalStep ? "Create my profile" : "Continue"}</PrimaryButton>
            {step > 0 ? <SecondaryButton accessibilityLabel="Go back one setup step" onPress={() => updateDraft({ step: step - 1 })} style={styles.backButton} labelStyle={styles.backLabel}>Back</SecondaryButton> : <Pressable accessibilityRole="button" accessibilityLabel="Skip setup and continue later" onPress={() => router.replace("/(tabs)" as any)} style={({ pressed }) => [styles.skip, pressed && styles.pressed]}><Text style={styles.skipText}>I’ll set this up later</Text></Pressable>}
          </View>
        </View>
      </ScrollView>
    </ScreenContainer>
  );
}

function Choice({ label, detail, selected, disabled, compact, onPress }: { label: string; detail?: string; selected: boolean; disabled?: boolean; compact?: boolean; onPress: () => void }) {
  return <Pressable accessibilityRole="radio" accessibilityState={{ selected, disabled }} accessibilityLabel={detail ? `${label}. ${detail}` : label} disabled={disabled} onPress={onPress} style={({ pressed }) => [styles.choice, compact && styles.compactChoice, selected && styles.choiceActive, disabled && styles.choiceDisabled, pressed && styles.pressed]}><View style={[styles.radio, selected && styles.radioActive]}>{selected ? <Text style={styles.check}>✓</Text> : null}</View><View style={styles.choiceCopy}><Text style={[styles.choiceText, selected && styles.choiceTextActive]}>{label}</Text>{detail ? <Text style={[styles.choiceDetail, selected && styles.choiceDetailActive]}>{detail}</Text> : null}</View></Pressable>;
}

const styles = StyleSheet.create({
  scrollContent: { flexGrow: 1 }, content: { flex: 1, justifyContent: "space-between", paddingTop: 52, paddingBottom: 24, minHeight: 700 }, loading: { flex: 1, justifyContent: "center", alignItems: "center" }, loadingText: { color: "#BFC6C9", fontSize: 16 }, topRow: { flexDirection: "row", justifyContent: "space-between", alignItems: "center" }, stepCount: { color: "#9EA8AC", fontSize: 12, fontWeight: "700" }, progressTrack: { height: 5, backgroundColor: "#3A4449", borderRadius: 5, marginTop: 14, overflow: "hidden" }, progressFill: { height: 5, backgroundColor: palette.coral, borderRadius: 5 }, title: { color: "#FFFFFF", fontSize: 36, lineHeight: 43, marginTop: 32 }, body: { color: "#BFC6C9", marginTop: 16, fontSize: 17, lineHeight: 25 }, introCard: { backgroundColor: "#2A3237", borderColor: "#465157", borderWidth: 1, borderRadius: 22, padding: 22, marginTop: 34 }, introMark: { color: palette.coral, fontSize: 14, fontWeight: "900", letterSpacing: 1.5 }, introTitle: { color: "#FFFFFF", fontSize: 21, fontWeight: "800", marginTop: 22, lineHeight: 27 }, introBody: { color: "#BFC6C9", fontSize: 15, lineHeight: 23, marginTop: 9 }, choices: { gap: 10, marginTop: 30 }, choice: { minHeight: 58, borderWidth: 1, borderColor: "#4B555A", borderRadius: 16, paddingHorizontal: 16, paddingVertical: 13, flexDirection: "row", alignItems: "center", gap: 12 }, compactChoice: { width: "48%" }, choiceActive: { backgroundColor: palette.coral, borderColor: palette.coral }, choiceDisabled: { opacity: 0.45 }, choiceCopy: { flex: 1 }, choiceText: { color: "#D5DBDD", fontSize: 15, fontWeight: "700", lineHeight: 20 }, choiceTextActive: { color: "#FFFFFF" }, choiceDetail: { color: "#9EA8AC", fontSize: 12, lineHeight: 17, marginTop: 3 }, choiceDetailActive: { color: "#FFE8E5" }, radio: { width: 24, height: 24, borderRadius: 12, borderWidth: 1.5, borderColor: "#7B878B", alignItems: "center", justifyContent: "center" }, radioActive: { backgroundColor: "#FFFFFF", borderColor: "#FFFFFF" }, check: { color: palette.coral, fontWeight: "900", fontSize: 15 }, selectionHint: { color: "#9EA8AC", fontSize: 13, fontWeight: "700", marginTop: 28, marginBottom: 12 }, interestGrid: { flexDirection: "row", flexWrap: "wrap", gap: 10 }, summary: { backgroundColor: "#2A3237", borderRadius: 16, padding: 16, marginTop: 18 }, summaryLabel: { color: palette.coral, fontSize: 11, fontWeight: "800", letterSpacing: 1.2 }, summaryText: { color: "#FFFFFF", fontSize: 14, lineHeight: 20, marginTop: 7 }, bottom: { gap: 12, marginTop: 36 }, dots: { flexDirection: "row", alignItems: "center", justifyContent: "space-between" }, dotGroup: { flexDirection: "row", gap: 6 }, dot: { width: 20, height: 5, borderRadius: 5, backgroundColor: "#3A4449" }, dotActive: { backgroundColor: palette.coral }, dotCaption: { color: "#9EA8AC", fontSize: 12 }, disabled: { opacity: 0.45 }, backButton: { backgroundColor: "transparent", borderColor: "#4B555A" }, backLabel: { color: "#D5DBDD" }, skip: { minHeight: 44, alignItems: "center", justifyContent: "center" }, skipText: { color: "#9EA8AC", fontSize: 13, fontWeight: "700" }, pressed: { opacity: 0.7, transform: [{ scale: 0.98 }] }, saveMessage: { color: "#F5C9C5", fontSize: 12, lineHeight: 17 },
});
