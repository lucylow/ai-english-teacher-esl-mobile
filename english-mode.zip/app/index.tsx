import { Redirect } from "expo-router";
import { ActivityIndicator, View } from "react-native";
import { useApp } from "@/src/context/app-context";
import { palette } from "@/src/ui";
export default function EntryScreen() { const { profile, hasHydrated } = useApp(); if (!hasHydrated) return <View style={{ flex: 1, backgroundColor: palette.canvas, alignItems: "center", justifyContent: "center" }}><ActivityIndicator color={palette.coral} /></View>; return profile.onboardingComplete ? <Redirect href="/(tabs)" /> : <Redirect href={"/onboarding" as any} />; }
