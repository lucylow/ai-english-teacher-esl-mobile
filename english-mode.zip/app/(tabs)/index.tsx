import { router } from "expo-router";
import { ActivityIndicator, Pressable, ScrollView, StyleSheet, Text, View } from "react-native";
import { ScreenContainer } from "@/components/screen-container";
import { AnimatedEntrance } from "@/components/animated-entrance";
import { AnimatedProgressBar } from "@/components/animated-progress-bar";
import { Avatar, Card, Eyebrow, palette, PrimaryButton, ScoreRing, SectionHeader, Title } from "@/src/ui";
import { useApp } from "@/src/context/app-context";
import { useDashboardData } from "@/src/data/hooks";
import { recommendScenario } from "@/src/recommendations";
import { focusGuidance, formatSkillLabel } from "@/src/progress";
import { homePracticeTarget } from "@/src/home";

export default function HomeScreen() {
  const { profile, scenarios } = useApp();
  const { data: dashboard, state: dashboardState, message: dashboardMessage, retry } = useDashboardData();
  const score = dashboard?.powerScore ?? 0;
  const focus = focusGuidance(profile.focusSkill);
  const focusScenario = recommendScenario(scenarios, profile.focusSkill, dashboard?.dailyMission.scenarioId);
  const missionTarget = homePracticeTarget(dashboard);
  return <ScreenContainer containerClassName="bg-[#F7F4EF]" className="px-5 pt-4">
    <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={styles.content}>
      {dashboardState !== "remote" && <Pressable accessibilityRole="button" accessibilityLabel={dashboardState === "error" ? "Retry loading dashboard data" : dashboardMessage} disabled={dashboardState !== "error"} onPress={dashboardState === "error" ? retry : undefined} style={({ pressed }) => [styles.dataStatus, pressed && styles.pressed]}>{dashboardState === "loading" && <ActivityIndicator size="small" color={palette.coral} />}<Text style={styles.dataStatusText}>{dashboardMessage}{dashboardState === "error" ? " Tap to retry." : ""}</Text></Pressable>}
      <AnimatedEntrance delay={0} style={styles.top}>
        <View><Eyebrow>ENGLISH MODE</Eyebrow><Title style={styles.greeting}>Good morning, {profile.firstName}</Title></View><Avatar />
      </AnimatedEntrance>
      <AnimatedEntrance delay={40}><Card style={styles.scoreCard}><View><Eyebrow>YOUR ENGLISH POWER SCORE</Eyebrow><Text style={styles.score}>{score}</Text><Text style={styles.delta}>+{dashboard?.weeklyDelta ?? 0} this week <Text style={styles.deltaArrow}>↗</Text></Text></View><ScoreRing score={score} size={108} /></Card></AnimatedEntrance>
      <AnimatedEntrance delay={80}><SectionHeader title="Today’s mission" action="See all" onAction={() => router.push("/(tabs)/practice" as any)} /></AnimatedEntrance>
      <AnimatedEntrance delay={120}><Card style={styles.mission}><View style={styles.missionIcon}><Text style={styles.mic}>●</Text></View><View style={styles.missionCopy}><Text style={styles.missionTitle}>{dashboard?.dailyMission.title ?? "Your next practice"}</Text><Text style={styles.missionSub}>{dashboard?.dailyMission.subtitle ?? "Complete a session to see your next challenge."}</Text></View><PrimaryButton accessibilityLabel="Start today’s mission" style={styles.startButton} onPress={() => missionTarget.kind === "session" ? router.push({ pathname: "/session/[id]" as any, params: { id: missionTarget.scenarioId } }) : router.push("/(tabs)/practice" as any)}>Start</PrimaryButton></Card></AnimatedEntrance>
      <AnimatedEntrance delay={160}><Card style={styles.focus}><View style={styles.focusHeader}><View style={styles.focusCopy}><Eyebrow>FOCUS SKILL</Eyebrow><Text style={styles.focusTitle}>{focus.title}</Text></View><Text style={styles.focusScore}>{profile.skills[profile.focusSkill]}%</Text></View><AnimatedProgressBar value={profile.skills[profile.focusSkill]} color={palette.coral} delay={120} /><Text style={styles.why}>{focus.body}</Text><PrimaryButton accessibilityLabel={`Practice ${formatSkillLabel(profile.focusSkill)}`} style={styles.practiceButton} onPress={() => router.push({ pathname: "/session/[id]" as any, params: { id: focusScenario?.id ?? "presentation" } })}>Practice {formatSkillLabel(profile.focusSkill)}</PrimaryButton></Card></AnimatedEntrance>
      <AnimatedEntrance delay={200}><View style={styles.streak}><View style={styles.streakMark}><Text style={styles.flame}>✦</Text></View><View><Text style={styles.streakTitle}>{dashboard?.streak ?? 0} day streak</Text><Text style={styles.streakSub}>Small practice adds up.</Text></View><Text style={styles.streakChevron}>›</Text></View></AnimatedEntrance>
    </ScrollView>
  </ScreenContainer>;
}

const styles = StyleSheet.create({ dataStatus: { flexDirection: "row", alignItems: "center", gap: 8, paddingVertical: 4 }, dataStatusText: { color: palette.slate, fontSize: 12 }, content: { paddingBottom: 40, gap: 16 }, top: { flexDirection: "row", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 6 }, greeting: { fontSize: 25, marginTop: 5 }, scoreCard: { flexDirection: "row", justifyContent: "space-between", alignItems: "center", padding: 22, backgroundColor: palette.charcoal }, score: { color: "#FFFFFF", fontSize: 58, lineHeight: 64, fontWeight: "800", letterSpacing: -2 }, delta: { color: palette.sage, fontWeight: "700", fontSize: 14 }, deltaArrow: { color: palette.sage, fontSize: 18 }, mission: { flexDirection: "row", alignItems: "center", gap: 13, padding: 16 }, missionIcon: { width: 46, height: 46, borderRadius: 16, backgroundColor: "#FBE1D9", alignItems: "center", justifyContent: "center" }, mic: { color: palette.coralDark, fontSize: 20 }, missionCopy: { flex: 1 }, missionTitle: { color: palette.charcoal, fontWeight: "800", fontSize: 15, lineHeight: 20 }, missionSub: { color: palette.slate, fontSize: 12, marginTop: 2 }, startButton: { minHeight: 40, paddingHorizontal: 15, borderRadius: 12 }, focus: { padding: 20 }, focusHeader: { flexDirection: "row", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 14 }, focusCopy: { flex: 1 }, focusTitle: { color: palette.charcoal, fontWeight: "800", fontSize: 20, lineHeight: 25, marginTop: 4 }, focusScore: { color: palette.coralDark, fontSize: 25, fontWeight: "800", marginLeft: 10 }, why: { color: palette.slate, fontSize: 13, lineHeight: 19, marginTop: 14 }, practiceButton: { marginTop: 16, minHeight: 44, backgroundColor: palette.coral }, streak: { flexDirection: "row", alignItems: "center", gap: 13, paddingVertical: 8 }, streakMark: { width: 42, height: 42, borderRadius: 21, backgroundColor: "#F5E7C6", alignItems: "center", justifyContent: "center" }, flame: { color: palette.gold, fontSize: 24 }, streakTitle: { color: palette.charcoal, fontSize: 16, fontWeight: "800" }, streakSub: { color: palette.slate, fontSize: 13, marginTop: 2 }, streakChevron: { color: palette.slate, fontSize: 28, marginLeft: "auto" }, pressed: { opacity: 0.72, transform: [{ scale: 0.985 }] } });
