import { ScrollView, StyleSheet, Text, View } from "react-native";
import { ScreenContainer } from "@/components/screen-container";
import { AnimatedEntrance } from "@/components/animated-entrance";
import { AnimatedProgressBar } from "@/components/animated-progress-bar";
import { Body, Card, Eyebrow, palette, ScoreRing, SectionHeader, Title } from "@/src/ui";
import { useApp } from "@/src/context/app-context";
import { recommendationOutcomeTrend } from "@/src/recommendations";
import { focusGuidance, scoreContext } from "@/src/progress";

export default function ProgressScreen() {
  const { profile, sessions } = useApp();
  const skills = Object.entries(profile.skills) as [string, number][];
  const score = Math.round(skills.reduce((sum, [, value]) => sum + value, 0) / skills.length);
  const recommendationTrend = recommendationOutcomeTrend(profile.recommendationOutcomes ?? {});
  const trendMax = Math.max(1, ...recommendationTrend.flatMap((point) => [point.started, point.completed]));
  const trendTotal = recommendationTrend.reduce((total, point) => total + point.started + point.completed, 0);
  const memoryEnabled = profile.memorySettings?.enabled !== false;
  const focus = focusGuidance(profile.focusSkill);
  const scoreSummary = scoreContext(sessions);

  return (
    <ScreenContainer containerClassName="bg-[#F7F4EF]" className="px-5 pt-4">
      <ScrollView contentContainerStyle={styles.content}>
        <AnimatedEntrance>
          <Eyebrow>YOUR ENGLISH JOURNEY</Eyebrow>
          <Title style={styles.title}>Progress that feels useful.</Title>
          <Body style={styles.lede}>See the skills getting stronger and the one worth practicing next.</Body>
        </AnimatedEntrance>
        <AnimatedEntrance delay={50}>
          <Card style={styles.hero}>
            <ScoreRing score={score} size={125} />
            <View style={styles.heroText}>
              <Text style={styles.change}>{scoreSummary.headline}</Text>
              <Text style={styles.caption}>Power Score snapshot</Text>
              <Text style={styles.small}>{scoreSummary.detail}</Text>
            </View>
          </Card>
        </AnimatedEntrance>
        <AnimatedEntrance delay={90}><SectionHeader title="Speaking profile" /></AnimatedEntrance>
        {skills.map(([label, value], index) => (
          <AnimatedEntrance delay={120 + index * 35} key={label}>
            <View style={styles.skill}>
              <View style={styles.skillTop}>
                <Text style={styles.skillLabel}>{label[0].toUpperCase() + label.slice(1)}</Text>
                <Text style={styles.skillValue}>{value}</Text>
              </View>
              <AnimatedProgressBar value={value} delay={180 + index * 35} color={label === profile.focusSkill ? palette.coral : palette.sage} />
            </View>
          </AnimatedEntrance>
        ))}
        <AnimatedEntrance delay={260}>
          <Card style={styles.focus}>
            <Eyebrow>FOCUS NEXT</Eyebrow>
            <Text style={styles.focusTitle}>{focus.title}</Text>
            <Text style={styles.focusBody}>{focus.body}</Text>
          </Card>
        </AnimatedEntrance>
        {memoryEnabled ? (
          <AnimatedEntrance delay={285}>
            <Card style={styles.trendCard}>
              <View style={styles.trendHeader}>
                <View style={styles.trendCopy}>
                  <Eyebrow>RECOMMENDATION RHYTHM</Eyebrow>
                  <Text style={styles.trendTitle}>A useful pattern, not a streak.</Text>
                </View>
                {trendTotal > 0 ? <Text style={styles.trendTotal}>{trendTotal} signals</Text> : null}
              </View>
              <Text style={styles.trendBody}>Your last four weeks of recommendation starts and completions.</Text>
              {trendTotal > 0 ? (
                <View style={styles.trendChart} accessibilityLabel="Four week recommendation outcome trend">
                  <View style={styles.trendLegend}>
                    <View style={styles.legendItem}><View style={[styles.legendDot, styles.startedDot]} /><Text style={styles.legendText}>Started</Text></View>
                    <View style={styles.legendItem}><View style={[styles.legendDot, styles.completedDot]} /><Text style={styles.legendText}>Completed</Text></View>
                  </View>
                  <View style={styles.bars}>
                    {recommendationTrend.map((point) => (
                      <View key={point.key} style={styles.barGroup} accessibilityLabel={`${point.label}: ${point.started} started, ${point.completed} completed`}>
                        <View style={styles.barPair}>
                          <View style={[styles.bar, styles.startedBar, { height: Math.max(4, (point.started / trendMax) * 72) }]} />
                          <View style={[styles.bar, styles.completedBar, { height: Math.max(4, (point.completed / trendMax) * 72) }]} />
                        </View>
                        <Text style={styles.barLabel}>{point.label}</Text>
                      </View>
                    ))}
                  </View>
                </View>
              ) : (
                <Text style={styles.emptyTrend}>Choose a recommended rehearsal and this space will begin to show your rhythm.</Text>
              )}
            </Card>
          </AnimatedEntrance>
        ) : null}
        <AnimatedEntrance delay={320}><SectionHeader title="Recent rehearsals" /></AnimatedEntrance>
        {sessions.slice(0, 3).map((session, index) => (
          <AnimatedEntrance delay={360 + index * 40} key={session.id}>
            <View style={styles.session}>
              <View>
                <Text style={styles.sessionTitle}>{session.scenarioTitle}</Text>
                <Text style={styles.sessionDate}>{new Date(session.completedAt).toLocaleDateString(undefined, { month: "short", day: "numeric" })}</Text>
              </View>
              <Text style={styles.sessionScore}>{session.score}</Text>
            </View>
          </AnimatedEntrance>
        ))}
      </ScrollView>
    </ScreenContainer>
  );
}

const styles = StyleSheet.create({
  content: { paddingBottom: 35, gap: 13 },
  title: { marginTop: 6 },
  lede: { marginTop: 2 },
  hero: { flexDirection: "row", alignItems: "center", gap: 18, padding: 16, marginTop: 6 },
  heroText: { flex: 1 },
  change: { color: palette.charcoal, fontSize: 24, fontWeight: "800" },
  caption: { color: palette.coralDark, fontWeight: "800", fontSize: 12, marginTop: 3 },
  small: { color: palette.slate, fontSize: 12, lineHeight: 17, marginTop: 12 },
  skill: { marginBottom: 6 },
  skillTop: { flexDirection: "row", justifyContent: "space-between", marginBottom: 7 },
  skillLabel: { color: palette.slate, fontSize: 14, fontWeight: "700" },
  skillValue: { color: palette.charcoal, fontWeight: "800" },
  focus: { backgroundColor: "#EAF0E9", marginTop: 4 },
  focusTitle: { color: palette.charcoal, fontSize: 22, fontWeight: "800", marginTop: 6 },
  focusBody: { color: palette.slate, lineHeight: 20, fontSize: 13, marginTop: 4 },
  trendCard: { backgroundColor: "#F1EEE8", marginTop: 3 },
  trendHeader: { flexDirection: "row", justifyContent: "space-between", alignItems: "flex-start" },
  trendCopy: { flex: 1 },
  trendTitle: { color: palette.charcoal, fontSize: 18, lineHeight: 23, fontWeight: "800", marginTop: 6 },
  trendTotal: { color: palette.coralDark, fontSize: 12, fontWeight: "800", marginTop: 4 },
  trendBody: { color: palette.slate, fontSize: 13, lineHeight: 19, marginTop: 5 },
  trendChart: { marginTop: 16 },
  trendLegend: { flexDirection: "row", gap: 14, marginBottom: 10 },
  legendItem: { flexDirection: "row", alignItems: "center", gap: 5 },
  legendDot: { width: 7, height: 7, borderRadius: 4 },
  startedDot: { backgroundColor: palette.coral },
  completedDot: { backgroundColor: palette.sage },
  legendText: { color: palette.slate, fontSize: 11, fontWeight: "700" },
  bars: { flexDirection: "row", alignItems: "flex-end", justifyContent: "space-between", minHeight: 96 },
  barGroup: { alignItems: "center", flex: 1 },
  barPair: { flexDirection: "row", alignItems: "flex-end", gap: 3, height: 74 },
  bar: { width: 9, borderRadius: 5, minHeight: 4 },
  startedBar: { backgroundColor: palette.coral },
  completedBar: { backgroundColor: palette.sage },
  barLabel: { color: palette.slate, fontSize: 10, marginTop: 7 },
  emptyTrend: { color: palette.slate, fontSize: 13, lineHeight: 19, marginTop: 15 },
  session: { flexDirection: "row", justifyContent: "space-between", alignItems: "center", paddingVertical: 12, borderBottomWidth: 1, borderBottomColor: palette.border },
  sessionTitle: { color: palette.charcoal, fontWeight: "800", fontSize: 14 },
  sessionDate: { color: palette.slate, marginTop: 4, fontSize: 12 },
  sessionScore: { color: palette.coralDark, fontWeight: "800", fontSize: 20 },
});
