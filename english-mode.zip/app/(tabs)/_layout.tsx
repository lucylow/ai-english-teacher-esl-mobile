import { Tabs } from "expo-router";
import { Platform } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { IconSymbol } from "@/components/ui/icon-symbol";
import { palette } from "@/src/ui";

export default function TabLayout() {
  const insets = useSafeAreaInsets();
  const bottom = Platform.OS === "web" ? 10 : Math.max(insets.bottom, 8);
  return <Tabs screenOptions={{ headerShown: false, tabBarActiveTintColor: palette.coral, tabBarInactiveTintColor: palette.slate, tabBarStyle: { height: 60 + bottom, paddingBottom: bottom, paddingTop: 7, backgroundColor: palette.surface, borderTopColor: palette.border }, tabBarLabelStyle: { fontSize: 11, fontWeight: "700" } }}>
    <Tabs.Screen name="index" options={{ title: "Home", tabBarIcon: ({ color }) => <IconSymbol name="house.fill" size={23} color={color} /> }} />
    <Tabs.Screen name="practice" options={{ title: "Practice", tabBarIcon: ({ color }) => <IconSymbol name="mic.fill" size={23} color={color} /> }} />
    <Tabs.Screen name="progress" options={{ title: "Progress", tabBarIcon: ({ color }) => <IconSymbol name="chart.bar.fill" size={23} color={color} /> }} />
    <Tabs.Screen name="time-machine" options={{ title: "Time Machine", tabBarIcon: ({ color }) => <IconSymbol name="clock.fill" size={23} color={color} /> }} />
    <Tabs.Screen name="profile" options={{ title: "Profile", tabBarIcon: ({ color }) => <IconSymbol name="person.fill" size={23} color={color} /> }} />
  </Tabs>;
}
