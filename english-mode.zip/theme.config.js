/** @type {const} */
const themeColors = {
  primary: { light: '#F06A5E', dark: '#F06A5E' },
  background: { light: '#F7F4EF', dark: '#1E2328' },
  surface: { light: '#FFFCF8', dark: '#313A40' },
  foreground: { light: '#1E2328', dark: '#FFFFFF' },
  muted: { light: '#6D747B', dark: '#BFC6C9' },
  border: { light: '#E7E1D8', dark: '#4B555A' },
  success: { light: '#22C55E', dark: '#4ADE80' },
  warning: { light: '#F59E0B', dark: '#FBBF24' },
  error: { light: '#EF4444', dark: '#F87171' },
};

module.exports = { themeColors };
