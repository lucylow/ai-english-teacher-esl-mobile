from PIL import Image
from pathlib import Path

source = Path('/home/ubuntu/webdev-static-assets/english-mode-icon.png')
targets = [
    Path('/home/ubuntu/english-mode/assets/images/icon.png'),
    Path('/home/ubuntu/english-mode/assets/images/splash-icon.png'),
    Path('/home/ubuntu/english-mode/assets/images/favicon.png'),
    Path('/home/ubuntu/english-mode/assets/images/android-icon-foreground.png'),
]
image = Image.open(source).convert('RGBA')
for target in targets:
    size = 512 if target.name != 'favicon.png' else 192
    resized = image.resize((size, size), Image.Resampling.LANCZOS)
    resized.save(target, format='PNG', optimize=True)
