# ENGLISH MODE — Mobile Interface Design Plan

## Product direction

ENGLISH MODE is an iOS-first speaking coach for learners who want to rehearse the English they will actually use. The interface should feel calm, premium, and editorial rather than childish or quiz-like. The primary interaction is speaking, with text and scores used to make practice feel concrete and actionable.

The app is designed for portrait orientation and one-handed use. Primary actions sit in the lower half of the screen or inside thumb-reachable cards. Every important action has a visible pressed state, a clear result, and an accessible label.

## Screen list

| Screen | Primary content and functionality |
|---|---|
| Welcome | Brand promise, concise explanation of real-life rehearsal, and entry into setup. |
| Goal setup | Select a primary speaking goal such as everyday conversation, presentations, interviews, travel, work, or social confidence. |
| Level setup | Select an approximate starting level using plain-language descriptions rather than grammar terminology. |
| Interests setup | Choose topics that should shape future scenarios, such as technology, music, travel, movies, or business. |
| Practice time setup | Select 5, 10, or 15 minutes per day and finish profile creation. |
| Home | Greeting, English Power Score, daily mission, focus skill, explanation of the recommendation, and streak. |
| Practice hub | Choose a situation or describe a custom upcoming situation. Show common categories and prompt shortcuts. |
| Scenario list | Show scenarios for one category with context, objective, skill focus, difficulty, duration, and start action. |
| Live rehearsal | Show scenario context, AI coach avatar, transcript, session progress, elapsed time, microphone control, pause/retry, and safe exit. |
| Evaluation | Show performance scores, three actionable improvements, transcript-based coaching, and next recommended rehearsal. |
| Progress | Show Power Score trend, skill cards, strongest skill, focus skill, and recent sessions. |
| Time Machine | Compare a past speaking moment with the current result, with a clear then/now narrative. |
| Profile | Show learner preferences, speaking profile, settings, privacy, and subscription entry point. |
| Paywall | Explain Pro value and pricing without blocking the free daily challenge or basic practice. |

## Navigation

Use a five-tab layout: **Home**, **Practice**, **Progress**, **Time Machine**, and **Profile**. Stack routes handle onboarding, category scenarios, live rehearsals, evaluation, and paywall screens. Returning users land on Home; new users complete the short setup flow first.

## Key user flows

### First-run setup

1. User opens ENGLISH MODE and sees the promise: “Practice the English you’ll actually need.”
2. User continues through a short explanation of real-life rehearsals.
3. User selects a primary goal, approximate level, interests, and preferred daily duration.
4. User taps “Create my profile” and is routed to Home with a starter learning profile.
5. Microphone permission is explained and requested only when the user starts a speaking rehearsal.

### Daily challenge

1. User opens Home and sees today’s deterministic 60-second mission.
2. User taps “Start challenge”.
3. Live rehearsal opens with a single clear speaking objective and a microphone control.
4. User records a response using the mock provider in development or the real provider when configured.
5. Evaluation shows scores and three improvements; the completed session updates streak and recent history.

### Situation rehearsal

1. User taps Practice in the tab bar.
2. User chooses a category such as Presentations or Travel.
3. User selects a scenario card and reviews its context, target skills, and duration.
4. User taps “Start rehearsal” and enters the live session.
5. User completes or exits safely, then sees the evaluation and next recommended challenge.

### Custom scenario

1. User chooses “Tell us what you need to practice”.
2. User enters a situation such as “I have to explain my project tomorrow.”
3. The app validates the text and generates a typed scenario through a provider abstraction; development mode uses a deterministic mock.
4. The generated scenario is shown for confirmation before entering the rehearsal.

### Time Machine

1. User opens Time Machine.
2. The app presents a past session and today’s comparable skill result.
3. User taps “Hear the difference” to reveal the then/now transcript comparison.
4. User can continue directly into a focused rehearsal targeting the older mistake.

## Visual layout rules

- Use an off-white canvas with charcoal text and a restrained electric coral accent for primary action.
- Keep the first viewport focused: one hero metric, one recommended action, one compact supporting insight.
- Use generous 20–24 pt horizontal padding and 24–32 pt vertical rhythm between sections.
- Use large rounded cards with subtle borders rather than heavy shadows.
- Primary CTA buttons are full-width, minimum 52 pt tall, and placed near the bottom of the active content.
- Use compact chips only for category, difficulty, and duration; do not create badge clutter.
- Scores use rings or bars with explicit labels and accessible text equivalents.
- Live rehearsal uses a quiet, dark charcoal stage so the microphone state and transcript feel immersive.
- Bottom tab bar remains light and low-contrast, with active coral icons and clear text labels.

## Color choices

| Token | Color | Use |
|---|---|---|
| Canvas | `#F7F4EF` | Warm background for all primary screens. |
| Surface | `#FFFCF8` | Cards, sheets, and elevated content. |
| Charcoal | `#1E2328` | Primary text and high-contrast session stage. |
| Slate | `#6D747B` | Secondary copy and metadata. |
| Border | `#E7E1D8` | Card outlines and separators. |
| Coral | `#F06A5E` | Primary action, active navigation, and score emphasis. |
| Coral dark | `#C94E45` | Pressed state and deep accent. |
| Sage | `#B8CBB8` | Positive improvement and supporting data visualization. |
| Gold | `#D9A441` | Streak and attention states. |
| Blue | `#5E81AC` | Pronunciation or information highlights. |
| Error | `#C94B4B` | Permission, network, or validation errors. |

## Typography and interaction

Use a strong display treatment for the Power Score and page titles, with readable 16–17 pt body copy and 13–14 pt metadata. Maintain line height above font size to avoid clipping. Buttons, cards, and icon controls must provide visible press feedback and minimum 44 pt touch targets. Use haptics only for primary actions and session completion. Support reduced motion by keeping transitions short and non-essential.

## Content tone

Copy should be direct, warm, and coach-like. Prefer “Here’s what to work on next” over “You failed”. Explain why a recommendation appears. Scores should be framed as a current snapshot, not a definitive assessment of language proficiency.
