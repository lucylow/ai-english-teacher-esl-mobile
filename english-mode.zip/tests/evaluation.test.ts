import { describe, expect, it } from "vitest";
import { averageEvaluationScore, evaluationMetrics, nextFocusMetric, nextPracticeAction } from "../src/evaluation";

const scores = { fluency: 80, grammar: 72, vocabulary: 61, pronunciation: 88, clarity: 75, conversation: 79 };

describe("evaluation presentation helpers", () => {
  it("builds the user-facing metric set in a stable order", () => {
    expect(evaluationMetrics(scores).map((metric) => metric.label)).toEqual(["Fluency", "Grammar", "Vocabulary", "Pronunciation"]);
  });

  it("calculates a rounded snapshot and identifies the next focus", () => {
    const metrics = evaluationMetrics(scores);
    expect(averageEvaluationScore(metrics)).toBe(75);
    const focus = nextFocusMetric(metrics);
    expect(focus).toMatchObject({ key: "vocabulary", value: 61 });
    expect(nextPracticeAction(focus)).toBe("Replace one general word with a more precise phrase that fits the situation.");
  });
});
