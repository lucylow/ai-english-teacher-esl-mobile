import { describe, expect, it } from "vitest";
import { homePracticeTarget } from "../src/home";

const dashboard = (scenarioId: string) => ({
  dailyMission: { title: "Mission", subtitle: "Practice", scenarioId },
});

describe("Home mission routing", () => {
  it("routes a populated daily mission to its scenario", () => {
    expect(homePracticeTarget(dashboard("interview"))).toEqual({ kind: "session", scenarioId: "interview" });
  });

  it("uses the Practice hub when the mission id is missing or blank", () => {
    expect(homePracticeTarget()).toEqual({ kind: "practice" });
    expect(homePracticeTarget(dashboard("   "))).toEqual({ kind: "practice" });
  });
});
