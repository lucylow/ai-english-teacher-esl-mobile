import { describe, expect, it } from "vitest";
import { recommendationOutcomeRationale, recommendationRationale } from "../src/recommendation-rationale";
import type { Scenario } from "../src/types";

const base: Scenario = { id: "scenario", title: "Scenario", category: "Test", context: "Test", objective: "Test", difficulty: "easy", estimatedMinutes: 5, openingLine: "Test", targetSkills: ["vocabulary"] };

describe("recommendation rationale", () => {
  it("explains direct focus alignment", () => {
    expect(recommendationRationale(base, "vocabulary")).toContain("strengthen your vocabulary");
  });

  it("explains varied fallback practice", () => {
    expect(recommendationRationale({ ...base, targetSkills: ["grammar"] }, "vocabulary")).toContain("keeps your speaking practice varied");
  });

  it("explains outcome-aware next steps", () => {
    expect(recommendationOutcomeRationale()).toContain("fresh situation");
    expect(recommendationOutcomeRationale({ startedAt: "2026-08-24T10:00:00.000Z" })).toContain("Pick up where you left off");
    expect(recommendationOutcomeRationale({ completedAt: "2026-08-24T10:05:00.000Z" })).toContain("revisit");
  });
});
