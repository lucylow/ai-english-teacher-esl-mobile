import { describe, expect, it } from "vitest";
import { isCurrentVoiceOperation, nextVoiceOperation } from "../src/voice-session-safety";

describe("voice session operation safety", () => {
  it("advances operation tokens so older async work becomes stale", () => {
    const first = nextVoiceOperation(0);
    const second = nextVoiceOperation(first);
    expect(isCurrentVoiceOperation(first, second)).toBe(false);
    expect(isCurrentVoiceOperation(second, second)).toBe(true);
  });
});
