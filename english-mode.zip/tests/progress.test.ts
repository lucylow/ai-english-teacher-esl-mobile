import { describe, expect, it } from "vitest";
import { formatSkillLabel, focusGuidance, scoreContext } from "../src/progress";
import type { SessionRecord } from "../src/types";

const session = (id: string, score: number, completedAt: string): SessionRecord => ({
  id,
  scenarioId: id,
  scenarioTitle: id,
  score,
  completedAt,
  durationSeconds: 60,
});

describe("Progress presentation helpers", () => {
  it("uses the most recent valid rehearsal and bounds its score", () => {
    expect(scoreContext([
      session("older", 64, "2026-08-18T08:30:00.000Z"),
      session("newer", 140, "2026-08-21T10:05:00.000Z"),
    ])).toEqual({
      headline: "Latest rehearsal · 100",
      detail: "Your Power Score blends six speaking skills across recent practice.",
    });
  });

  it("falls back to neutral score context when no valid rehearsal exists", () => {
    expect(scoreContext([
      session("invalid-date", 74, "not-a-date"),
      session("invalid-score", Number.NaN, "2026-08-21T10:05:00.000Z"),
    ])).toEqual({
      headline: "Current score",
      detail: "Complete a rehearsal to start a personal comparison.",
    });
  });

  it("keeps focus guidance aligned with the selected skill", () => {
    expect(formatSkillLabel("conversation")).toBe("Conversation");
    expect(focusGuidance("grammar")).toEqual({
      title: "Make each thought land",
      body: "Slow down at sentence turns and finish each thought with a clear, simple structure.",
    });
  });
});
