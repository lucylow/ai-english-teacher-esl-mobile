import { describe, expect, it } from "vitest";
import { lessonResumeCopy, normalizeLessonDraft, shouldResumeLesson } from "../src/lesson-draft";

describe("lesson draft helpers", () => {
  it("rejects malformed drafts and clamps oversized selections", () => {
    expect(normalizeLessonDraft({ step: 3, selected: "x", updatedAt: "today" }, 3)).toBeUndefined();
    expect(normalizeLessonDraft({ step: 1.5, selected: "x", updatedAt: "today" }, 3)).toBeUndefined();
    expect(normalizeLessonDraft({ step: 1, selected: "x".repeat(300), updatedAt: "today" }, 3)?.selected).toHaveLength(240);
  });

  it("preserves valid score state while defaulting legacy drafts", () => {
    expect(normalizeLessonDraft({ step: 2, selected: "", correctCount: 1, updatedAt: "today" }, 4)?.correctCount).toBe(1);
    expect(normalizeLessonDraft({ step: 2, selected: "", updatedAt: "today" }, 4)?.correctCount).toBe(0);
  });

  it("rejects invalid persisted score state", () => {
    expect(normalizeLessonDraft({ step: 1, selected: "", correctCount: -1, updatedAt: "today" }, 4)).toBeUndefined();
    expect(normalizeLessonDraft({ step: 1, selected: "", correctCount: 5, updatedAt: "today" }, 4)).toBeUndefined();
    expect(normalizeLessonDraft({ step: 1, selected: "", correctCount: 1.5, updatedAt: "today" }, 4)).toBeUndefined();
  });

  it("formats useful resume progress without leaking invalid values", () => {
    expect(lessonResumeCopy(2, 1, 4)).toBe("1 correct so far · Activity 3 of 4");
    expect(lessonResumeCopy(-3, -1, 4)).toBe("0 correct so far · Activity 1 of 4");
    expect(lessonResumeCopy(9, 8, 4)).toBe("4 correct so far · Activity 4 of 4");
  });

  it("only offers resume when the learner has made progress", () => {
    expect(shouldResumeLesson(undefined)).toBe(false);
    expect(shouldResumeLesson({ step: 0, selected: "", updatedAt: "today" })).toBe(false);
    expect(shouldResumeLesson({ step: 1, selected: "", updatedAt: "today" })).toBe(true);
  });
});
