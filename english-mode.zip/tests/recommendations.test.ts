import { describe, expect, it } from "vitest";
import { latestCompletedRecommendationId, latestCompletedRecommendationScore, recommendScenario, recommendationOutcomeLabel, recommendationOutcomeTrend, updateRecommendationOutcome } from "../src/recommendations";
import type { Scenario } from "../src/types";

const scenario = (id: string, targetSkills: Scenario["targetSkills"]): Scenario => ({ id, title: id, category: "Test", context: "Test", objective: "Test objective", difficulty: "easy", estimatedMinutes: 5, openingLine: "Test", targetSkills });

describe("scenario recommendations", () => {
  it("prefers an uncompleted scenario targeting the focus skill", () => {
    const result = recommendScenario([scenario("current", ["vocabulary"]), scenario("targeted", ["vocabulary"]), scenario("other", ["grammar"])], "vocabulary", "current");
    expect(result?.id).toBe("targeted");
  });

  it("chooses a separate focus-skill scenario when today’s mission is excluded", () => {
    const result = recommendScenario([scenario("mission", ["vocabulary"]), scenario("focus", ["vocabulary"]), scenario("other", ["grammar"])], "vocabulary", "mission");
    expect(result?.id).toBe("focus");
  });

  it("moves recently chosen scenarios behind fresh options", () => {
    const result = recommendScenario([scenario("chosen", ["vocabulary"]), scenario("fresh", ["vocabulary"])], "vocabulary", undefined, ["chosen"]);
    expect(result?.id).toBe("fresh");
  });

  it("bounds the latest recommendation score and handles missing sessions", () => {
    const outcomes = { scenario: { completedAt: "2026-08-24T11:00:00.000Z" } };
    expect(latestCompletedRecommendationScore(outcomes, [{ id: "1", scenarioId: "scenario", scenarioTitle: "Scenario", score: 140, completedAt: "2026-08-24T11:00:00.000Z", durationSeconds: 30 }])).toBe(100);
    expect(latestCompletedRecommendationScore(outcomes, [])).toBeUndefined();
  });

  it("selects the most recent completed recommendation", () => {
    expect(latestCompletedRecommendationId({ older: { completedAt: "2026-08-24T10:00:00.000Z" }, newer: { completedAt: "2026-08-24T11:00:00.000Z" }, active: { startedAt: "2026-08-24T12:00:00.000Z" } })).toBe("newer");
    expect(latestCompletedRecommendationId({ active: { startedAt: "2026-08-24T12:00:00.000Z" } })).toBeUndefined();
  });

  it("groups recommendation starts and completions into four UTC weeks", () => {
    const trend = recommendationOutcomeTrend({
      first: { startedAt: "2026-08-04T09:00:00.000Z", completedAt: "2026-08-06T09:00:00.000Z" },
      second: { startedAt: "2026-08-11T09:00:00.000Z" },
      third: { completedAt: "2026-08-17T09:00:00.000Z" },
      outside: { startedAt: "2026-08-01T09:00:00.000Z" },
      invalid: { completedAt: "not-a-date" },
    }, new Date("2026-08-24T12:00:00.000Z"));
    expect(trend).toHaveLength(4);
    expect(trend.map(({ started, completed }) => ({ started, completed }))).toEqual([
      { started: 1, completed: 1 },
      { started: 1, completed: 0 },
      { started: 0, completed: 1 },
      { started: 0, completed: 0 },
    ]);
  });

  it("returns a stable empty four-week trend", () => {
    expect(recommendationOutcomeTrend({}, new Date("2026-08-24T12:00:00.000Z")).map(({ started, completed }) => ({ started, completed }))).toEqual([
      { started: 0, completed: 0 },
      { started: 0, completed: 0 },
      { started: 0, completed: 0 },
      { started: 0, completed: 0 },
    ]);
  });

  it("labels recommendation status clearly", () => {
    expect(recommendationOutcomeLabel()).toBe("New practice");
    expect(recommendationOutcomeLabel({ startedAt: "2026-08-24T10:00:00.000Z" })).toBe("In progress");
    expect(recommendationOutcomeLabel({ completedAt: "2026-08-24T10:05:00.000Z" })).toBe("Revisit for confidence");
  });

  it("records started and completed outcomes without losing prior timestamps", () => {
    const started = updateRecommendationOutcome({}, "scenario", "started", "2026-08-24T10:00:00.000Z");
    const completed = updateRecommendationOutcome(started, "scenario", "completed", "2026-08-24T10:05:00.000Z");
    expect(completed.scenario).toEqual({ startedAt: "2026-08-24T10:00:00.000Z", completedAt: "2026-08-24T10:05:00.000Z" });
  });

  it("falls back safely when no scenario targets the skill", () => {
    expect(recommendScenario([scenario("current", ["grammar"]), scenario("other", ["fluency"])], "vocabulary", "current")?.id).toBe("other");
    expect(recommendScenario([], "vocabulary")).toBeUndefined();
  });
});
