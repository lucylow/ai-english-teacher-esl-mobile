import { describe, expect, it } from "vitest";
import { isLessonComplete, lessonCompletionMessage, lessonFeedback, lessonProgress, lessonScore } from "../src/lesson";

describe("guided lesson helpers", () => {
  it("reports activity progress from the current one-based position", () => {
    expect(lessonProgress(0, 5)).toBe(20);
    expect(lessonProgress(4, 5)).toBe(100);
    expect(lessonProgress(8, 5)).toBe(100);
  });

  it("keeps feedback concise and actionable", () => {
    expect(lessonFeedback("because", "because")).toBe("That’s right.");
    expect(lessonFeedback("although", "because")).toBe("Keep going.");
    expect(lessonFeedback("", "because")).toBe("");
  });

  it("calculates a bounded completion score", () => {
    expect(lessonScore(2, 2)).toBe(100);
    expect(lessonScore(1, 2)).toBe(50);
    expect(lessonScore(-1, 2)).toBe(0);
    expect(lessonScore(1, 0)).toBe(0);
  });

  it("uses supportive completion language at each score range", () => {
    expect(lessonCompletionMessage(90)).toContain("strong foundation");
    expect(lessonCompletionMessage(65)).toContain("useful progress");
    expect(lessonCompletionMessage(20)).toContain("clear place");
  });

  it("identifies the final activity safely", () => {
    expect(isLessonComplete(2, 3)).toBe(true);
    expect(isLessonComplete(1, 3)).toBe(false);
    expect(isLessonComplete(0, 0)).toBe(false);
  });
});
