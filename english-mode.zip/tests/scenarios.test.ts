import { describe, expect, it } from "vitest";
import { scenarios } from "../src/data/mock";

describe("uploaded roleplay scenario integration", () => {
  it("includes clarification practice with a conversation cue", () => {
    const scenario = scenarios.find((item) => item.id === "clarify");
    expect(scenario).toMatchObject({
      title: "Ask for clarification",
      targetSkills: expect.arrayContaining(["conversation", "clarity"]),
      coachCue: "Ask one short question before you answer; keep the conversation moving.",
    });
  });

  it("includes misunderstanding repair practice with a clear restatement cue", () => {
    const scenario = scenarios.find((item) => item.id === "repair");
    expect(scenario).toMatchObject({
      title: "Repair a misunderstanding",
      targetSkills: expect.arrayContaining(["conversation", "clarity"]),
      coachCue: "Acknowledge the misunderstanding, then restate your meaning in one clear sentence.",
    });
  });
});

