import { describe, expect, it } from "vitest";
import { detectGrammarSignals, grammarSignalCopy, parseGrammarSignals, serializeGrammarSignals } from "../src/grammar-signals";

describe("local grammar signals", () => {
  it("detects an article mismatch without flagging unrelated words", () => {
    expect(detectGrammarSignals(["I saw a orange sign."])).toEqual([{ category: "article", suggestion: "an" }]);
    expect(detectGrammarSignals(["The umbrella is ready."])).toEqual([]);
  });

  it("detects supported collocation repairs", () => {
    const signals = detectGrammarSignals(["I do a mistake when I rush."]);
    expect(signals).toEqual([{ category: "collocation", suggestion: "make a mistake" }]);
    expect(grammarSignalCopy(signals)).toContain("make a mistake");
  });

  it("detects a likely past-tense mismatch and agreement mismatch", () => {
    expect(detectGrammarSignals(["Yesterday I go to the office."])).toContainEqual({ category: "tense", suggestion: "use the past tense" });
    expect(detectGrammarSignals(["She work on the report."])).toContainEqual({ category: "agreement", suggestion: "check the verb form" });
    expect(detectGrammarSignals(["Yesterday I went to the office."])).not.toContainEqual({ category: "tense", suggestion: "use the past tense" });
  });

  it("serializes only bounded signal data", () => {
    const encoded = serializeGrammarSignals([{ category: "article", suggestion: "an" }, { category: "article", suggestion: "an" }, { category: "tense", suggestion: "use the past tense" }, { category: "unknown" as never, suggestion: "private" }]);
    expect(encoded).toBe("article:an|tense:use the past tense");
    expect(parseGrammarSignals(encoded)).toEqual([{ category: "article", suggestion: "an" }, { category: "tense", suggestion: "use the past tense" }]);
  });
});

