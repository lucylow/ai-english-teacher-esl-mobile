import { describe, expect, it } from "vitest";
import {
  canAdvanceOnboarding,
  DEFAULT_ONBOARDING_DRAFT,
  normalizeOnboardingDraft,
  profilePatchFromOnboarding,
} from "../src/onboarding";

describe("ENGLISH MODE onboarding", () => {
  it("normalizes malformed drafts to safe supported choices", () => {
    const draft = normalizeOnboardingDraft({ step: 99, goal: "unknown", level: "", interests: ["Travel", 4, "Unknown"], preferredDuration: 60 });
    expect(draft).toEqual({ step: 4, goal: "Presentations", level: "Finding my flow", interests: ["Travel"], preferredDuration: 10 });
  });

  it("requires a selected interest and limits the selection to three topics", () => {
    expect(canAdvanceOnboarding(3, { ...DEFAULT_ONBOARDING_DRAFT, interests: [] })).toBe(false);
    expect(canAdvanceOnboarding(3, { ...DEFAULT_ONBOARDING_DRAFT, interests: ["Technology", "Music", "Travel"] })).toBe(true);
    expect(canAdvanceOnboarding(3, { ...DEFAULT_ONBOARDING_DRAFT, interests: ["Technology", "Music", "Travel", "Movies"] })).toBe(false);
  });

  it("maps the completed draft to a learner profile patch", () => {
    expect(profilePatchFromOnboarding({ ...DEFAULT_ONBOARDING_DRAFT, goal: "Travel", level: "Ready to stretch", interests: ["Travel", "Food"], preferredDuration: 15 })).toEqual({ goal: "Travel", level: "Ready to stretch", interests: ["Travel", "Food"], preferredDuration: 15 });
  });
});
