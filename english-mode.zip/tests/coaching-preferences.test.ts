import { describe, expect, it } from "vitest";
import { coachingSignalEnabled, isDefaultCoachingSettings, normalizeCoachingSettings } from "../src/coaching-preferences";

describe("coaching preferences", () => {
  it("defaults missing or malformed settings to enabled cues", () => {
    expect(normalizeCoachingSettings(undefined)).toEqual({ fillers: true, grammar: true });
    expect(normalizeCoachingSettings({ fillers: false })).toEqual({ fillers: false, grammar: true });
    expect(normalizeCoachingSettings("not-settings")).toEqual({ fillers: true, grammar: true });
  });

  it("identifies whether the reset action is needed", () => {
    expect(isDefaultCoachingSettings({ fillers: true, grammar: true })).toBe(true);
    expect(isDefaultCoachingSettings({ fillers: false, grammar: true })).toBe(false);
  });

  it("reads each learner-controlled signal independently", () => {
    const settings = normalizeCoachingSettings({ fillers: false, grammar: true });
    expect(coachingSignalEnabled(settings, "fillers")).toBe(false);
    expect(coachingSignalEnabled(settings, "grammar")).toBe(true);
  });
});

