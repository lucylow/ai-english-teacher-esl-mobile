import { describe, expect, it } from "vitest";
import { rehearsalMicHint, rehearsalProgress, shouldConfirmRehearsalReset, voiceStatusLabel } from "../src/rehearsal";

describe("rehearsal presentation helpers", () => {
  it("clamps response progress and keeps the visual count bounded", () => {
    expect(rehearsalProgress(-1)).toEqual({ completed: 0, total: 3, percent: 0, label: "0 of 3 responses" });
    expect(rehearsalProgress(2.9)).toEqual({ completed: 2, total: 3, percent: 67, label: "2 of 3 responses" });
    expect(rehearsalProgress(8)).toEqual({ completed: 3, total: 3, percent: 100, label: "3 of 3 responses" });
  });

  it("explains microphone permission and transcription recovery states", () => {
    expect(rehearsalMicHint({ error: "MIC_PERMISSION_DENIED", isProcessing: false, listening: false })).toBe("Enable microphone access, then try again");
    expect(rehearsalMicHint({ error: "TRANSCRIPTION_ERROR", isProcessing: false, listening: false })).toBe("We couldn’t catch that. Tap to try again");
    expect(voiceStatusLabel({ error: "MIC_PERMISSION_DENIED", isProcessing: false, listening: false })).toBe("Microphone access is off");
    expect(voiceStatusLabel({ error: null, isProcessing: true, listening: false })).toBe("Getting your coaching ready...");
    expect(rehearsalMicHint({ error: null, isProcessing: false, listening: false, responsesCompleted: 3 })).toBe("Three responses captured — see your coaching");
    expect(shouldConfirmRehearsalReset(0, 0)).toBe(false);
    expect(shouldConfirmRehearsalReset(1, 0)).toBe(true);
    expect(shouldConfirmRehearsalReset(0, 4)).toBe(true);
  });
});
