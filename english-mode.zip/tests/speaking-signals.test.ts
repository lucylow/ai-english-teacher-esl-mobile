import { describe, expect, it } from "vitest";
import { detectFillerWords, fillerCoachingCopy, parseFillerWords, serializeFillerWords } from "../src/speaking-signals";

describe("local speaking signals", () => {
  it("detects supported filler phrases without false substring matches", () => {
    expect(detectFillerWords(["Um, I like the idea", "You know, we can improve it."])).toEqual(["um", "like", "you know"]);
    expect(detectFillerWords(["The umbrella is ready."])).toEqual([]);
  });

  it("keeps route serialization bounded to supported filler words", () => {
    const encoded = serializeFillerWords(["um", "private note", "uh"]);
    expect(encoded).toBe("um,uh");
    expect(parseFillerWords(encoded)).toEqual(["um", "uh"]);
  });

  it("returns a specific but non-judgmental coaching cue", () => {
    expect(fillerCoachingCopy(["um", "like"])).toBe("A short pause can replace um, like and help your next answer sound more deliberate.");
    expect(fillerCoachingCopy([])).toContain("short pause");
  });
});

