const MAX_RESPONSES = 3;

type RehearsalMicState = { error?: string | null; isProcessing: boolean; listening: boolean; responsesCompleted?: number };

export function rehearsalProgress(responseCount: number) {
  const completed = Number.isFinite(responseCount) ? Math.max(0, Math.min(MAX_RESPONSES, Math.floor(responseCount))) : 0;
  return {
    completed,
    total: MAX_RESPONSES,
    percent: Math.round((completed / MAX_RESPONSES) * 100),
    label: `${completed} of ${MAX_RESPONSES} responses`,
  };
}

export function rehearsalMicHint({ error, isProcessing, listening, responsesCompleted }: RehearsalMicState) {
  if (error === "MIC_PERMISSION_DENIED") return "Enable microphone access, then try again";
  if (error === "TRANSCRIPTION_ERROR") return "We couldn’t catch that. Tap to try again";
  if (error) return "Something went wrong. Tap to try again";
  if (isProcessing) return "Preparing your feedback...";
  if (listening) return "Tap to finish your answer";
  if ((responsesCompleted ?? 0) >= 3) return "Three responses captured — see your coaching";
  return "Tap to speak";
}

export function shouldConfirmRehearsalReset(responseCount: number, elapsedSeconds: number) {
  return (Number.isFinite(responseCount) && responseCount > 0) || (Number.isFinite(elapsedSeconds) && elapsedSeconds > 0);
}

export function voiceStatusLabel({ error, isProcessing, listening }: RehearsalMicState) {
  if (error === "MIC_PERMISSION_DENIED") return "Microphone access is off";
  if (error === "TRANSCRIPTION_ERROR") return "Couldn’t catch that answer";
  if (error) return "Microphone unavailable — try again";
  if (isProcessing) return "Getting your coaching ready...";
  if (listening) return "Listening to you...";
  return "Ready when you are";
}
