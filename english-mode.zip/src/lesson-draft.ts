export type LessonDraft = { step: number; selected: string; updatedAt: string; correctCount?: number };

export function normalizeLessonDraft(value: unknown, total: number): LessonDraft | undefined {
  if (!value || typeof value !== "object" || total <= 0) return undefined;
  const candidate = value as Partial<LessonDraft>;
  if (typeof candidate.step !== "number" || !Number.isInteger(candidate.step) || candidate.step < 0 || candidate.step >= total) return undefined;
  if (typeof candidate.selected !== "string" || typeof candidate.updatedAt !== "string") return undefined;
  const correctCount = candidate.correctCount === undefined ? 0 : candidate.correctCount;
  if (typeof correctCount !== "number" || !Number.isInteger(correctCount) || correctCount < 0 || correctCount > total) return undefined;
  return { step: candidate.step, selected: candidate.selected.slice(0, 240), updatedAt: candidate.updatedAt, correctCount };
}

export function shouldResumeLesson(draft: LessonDraft | undefined) {
  return Boolean(draft && (draft.step > 0 || draft.selected.length > 0));
}

export function lessonResumeCopy(step: number, correctCount: number, total: number) {
  const activity = total > 0 ? Math.min(total, Math.max(1, step + 1)) : 0;
  const correct = Math.min(Math.max(0, correctCount), Math.max(0, total));
  return `${correct} correct so far · Activity ${activity} of ${Math.max(0, total)}`;
}
