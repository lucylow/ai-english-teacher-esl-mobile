import { Platform } from "react-native";

export type NetworkStatus = "online" | "offline" | "unknown";

export function currentNetworkStatus(): NetworkStatus { if (Platform.OS === "web" && typeof navigator !== "undefined") return navigator.onLine ? "online" : "offline"; return "unknown"; }

export function shouldAttemptRemoteRequest() { return currentNetworkStatus() !== "offline"; }
