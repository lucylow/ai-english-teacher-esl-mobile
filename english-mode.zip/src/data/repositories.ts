import type { Evaluation, LearningProfile, Scenario, SessionRecord } from "@/src/types";
import { ApiClient } from "@/src/data/api";

export interface Repository<T> { get(id: string): Promise<T>; list(): Promise<T[]>; }

export function createRemoteRepositories(api = new ApiClient()) { return { profile: { get: () => api.get<LearningProfile>("/profile"), update: (patch: Partial<LearningProfile>) => api.post<LearningProfile>("/profile", patch) }, scenarios: { list: () => api.get<Scenario[]>("/scenarios"), get: (id: string) => api.get<Scenario>(`/scenarios/${id}`) }, sessions: { list: () => api.get<SessionRecord[]>("/sessions"), create: (scenarioId: string) => api.post<SessionRecord>("/sessions", { scenarioId }), complete: (id: string) => api.post<Evaluation>(`/sessions/${id}/complete`, {}) } }; }
