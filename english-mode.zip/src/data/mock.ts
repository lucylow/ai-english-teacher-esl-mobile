import type { Evaluation, LearningProfile, Scenario, SessionRecord } from "../types";

export const starterProfile: LearningProfile = {
  firstName: "Alex",
  goal: "Presentations",
  level: "Comfortable speaker",
  interests: ["Technology", "Music"],
  preferredDuration: 10,
  tone: "supportive",
  skills: { fluency: 72, grammar: 81, vocabulary: 68, pronunciation: 77, clarity: 74, conversation: 63 },
  focusSkill: "vocabulary",
  streak: 12,
  onboardingComplete: false,
  memorySettings: { enabled: true, saveMistakes: true, savePreferences: true, saveAudio: false },
  memoryNotes: ["You want to sound more natural when explaining ideas."],
};

export const scenarios: Scenario[] = [
  { id: "presentation", title: "Explain your project", category: "Presentations", context: "You are presenting a technology project to a classmate who asks thoughtful follow-up questions.", objective: "Practice explaining ideas clearly and defending one opinion.", difficulty: "comfortable", estimatedMinutes: 7, openingLine: "I’m curious about your project. What problem does it solve?", targetSkills: ["vocabulary", "clarity", "conversation"] },
  { id: "hotel", title: "Check into a hotel", category: "Travel", context: "You have arrived at a hotel and need to check in, ask about breakfast, and solve one small issue.", objective: "Practice polite requests and spontaneous answers while travelling.", difficulty: "easy", estimatedMinutes: 5, openingLine: "Welcome. May I see your passport, please?", targetSkills: ["conversation", "fluency"] },
  { id: "opinion", title: "Defend your point of view", category: "Everyday Life", context: "A friend asks whether technology makes everyday life better or more complicated.", objective: "Practice giving reasons, examples, and a balanced opinion.", difficulty: "stretch", estimatedMinutes: 8, openingLine: "Do you think technology has made life better? Why?", targetSkills: ["fluency", "vocabulary", "clarity"] },
  { id: "interview", title: "Answer an interview question", category: "Interviews", context: "You are in a friendly first-round interview for a role you care about.", objective: "Practice concise answers with a specific example.", difficulty: "stretch", estimatedMinutes: 7, openingLine: "Tell me about a time you solved a difficult problem.", targetSkills: ["conversation", "fluency", "grammar"] },
  { id: "clarify", title: "Ask for clarification", category: "Everyday Life", context: "Someone gives you instructions quickly, and you need to ask them to repeat or explain one detail.", objective: "Practice asking for clarification naturally while keeping the conversation moving.", difficulty: "easy", estimatedMinutes: 5, openingLine: "The meeting starts at nine, and bring the revised version with you.", targetSkills: ["conversation", "clarity", "fluency"], coachCue: "Ask one short question before you answer; keep the conversation moving." },
  { id: "repair", title: "Repair a misunderstanding", category: "Everyday Life", context: "You realize the other person misunderstood your meaning, so you need to correct yourself calmly and continue.", objective: "Practice repairing a misunderstanding without stopping the conversation.", difficulty: "comfortable", estimatedMinutes: 6, openingLine: "So you want the meeting moved to Friday?", targetSkills: ["conversation", "clarity", "fluency"], coachCue: "Acknowledge the misunderstanding, then restate your meaning in one clear sentence." },
];

export const sessions: SessionRecord[] = [
  { id: "session-1", scenarioId: "hotel", scenarioTitle: "Check into a hotel", score: 68, completedAt: "2026-08-18T08:30:00.000Z", durationSeconds: 312 },
  { id: "session-2", scenarioId: "opinion", scenarioTitle: "Defend your point of view", score: 71, completedAt: "2026-08-20T09:10:00.000Z", durationSeconds: 420 },
  { id: "session-3", scenarioId: "presentation", scenarioTitle: "Explain your project", score: 74, completedAt: "2026-08-21T10:05:00.000Z", durationSeconds: 388 },
];

export const evaluations: Evaluation[] = [{
  id: "eval-1", scenarioId: "presentation", completedAt: "2026-08-21T10:12:00.000Z",
  scores: { fluency: 72, grammar: 81, vocabulary: 68, pronunciation: 77, clarity: 74, conversation: 63 },
  improvements: [
    { title: "Make your connectors more varied", detail: "You use “but” several times. Try “however” or “on the other hand” to link ideas.", example: "However, the most useful part is..." },
    { title: "Add one more supporting detail", detail: "Your answer is clear. One specific example would make your explanation more memorable." },
    { title: "Give yourself a beat", detail: "A short pause before your opinion will help your answer sound more intentional." },
  ],
}];

export const starterDashboard = { powerScore: 73, weeklyDelta: 3, focusSkill: "vocabulary" as const, dailyMission: { title: "Explain something you know", subtitle: "for 60 seconds · Vocabulary focus", scenarioId: "presentation" }, streak: 12 };
