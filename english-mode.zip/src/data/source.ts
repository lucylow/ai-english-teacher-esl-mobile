import { appConfig, assertNoMocksInProduction, canUseRemoteData } from "../config";
import { normalizeError } from "../errors";

export type DataSourceState = "loading" | "remote" | "development-fallback" | "empty" | "offline" | "error";

export function resolveDataSourceState(args: { loading?: boolean; hasData?: boolean; offline?: boolean; error?: boolean } = {}, config = appConfig): DataSourceState { assertNoMocksInProduction(config); if (args.loading) return "loading"; if (args.offline) return "offline"; if (args.error) return "error"; if (!args.hasData) return canUseRemoteData(config) ? "empty" : "development-fallback"; return canUseRemoteData(config) ? "remote" : "development-fallback"; }

export function canUseDevelopmentFallback(config = appConfig) {
  return config.environment === "development" && config.mockMode;
}

export function resolveDataFailure(error: unknown, config = appConfig) {
  assertNoMocksInProduction(config);
  const normalized = normalizeError(error);
  return {
    state: canUseDevelopmentFallback(config) ? "development-fallback" as const : normalized.code === "offline" ? "offline" as const : "error" as const,
    message: normalized.message,
    retryable: normalized.retryable,
  };
}

export function dataSourceMessage(state: DataSourceState) { switch (state) { case "loading": return "Loading your learning data…"; case "offline": return "You’re offline. Saved practice remains available."; case "error": return "We couldn’t load this yet. Try again."; case "empty": return "Nothing here yet. Complete a practice session to get started."; case "development-fallback": return "Development content is active. Connect the production data service before release."; default: return ""; } }
