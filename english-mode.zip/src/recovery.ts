import type { AppError } from "@/src/errors";

export function safeRouteId(value: string | string[] | undefined, fallback: string) { const candidate = Array.isArray(value) ? value[0] : value; return candidate && /^[a-z0-9-]{1,80}$/i.test(candidate) ? candidate : fallback; }

export function diagnosticId(error: Pick<AppError, "code"> | { code?: string }, nonce = "local") { const input = `${error.code ?? "unknown"}:${nonce}`; let hash = 0; for (let index = 0; index < input.length; index += 1) hash = (hash * 31 + input.charCodeAt(index)) >>> 0; return `EM-${hash.toString(36).toUpperCase().padStart(6, "0")}`; }

export function retryLabel(retryable: boolean) { return retryable ? "Try again" : "Return to practice"; }
