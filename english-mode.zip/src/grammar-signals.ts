export type GrammarSignalCategory = "article" | "collocation" | "tense" | "agreement";

export type GrammarSignal = {
  category: GrammarSignalCategory;
  suggestion?: string;
};

const COLLOCATION_REPAIRS = [
  ["do a decision", "make a decision"],
  ["do a mistake", "make a mistake"],
  ["strong rain", "heavy rain"],
] as const;

const COMMON_PRESENT_VERBS = "go|work|visit|see|eat|meet|have|do|make|take|start|finish|live|want|need|like|play";
const PAST_MARKERS = /\b(yesterday|last week|last month|ago|earlier)\b/i;
const AGREEMENT_SUBJECTS = /\b(he|she|it)\s+(go|work|visit|see|eat|meet|have|do|make|take|start|finish|live|want|need|like|play)\b/i;

export function detectGrammarSignals(turns: string[]): GrammarSignal[] {
  const text = turns.join(" ").toLowerCase();
  const signals: GrammarSignal[] = [];
  if (/\ba\s+[aeiou][a-z']*/i.test(text)) signals.push({ category: "article", suggestion: "an" });
  for (const [incorrect, correct] of COLLOCATION_REPAIRS) {
    if (text.includes(incorrect)) signals.push({ category: "collocation", suggestion: correct });
  }
  if (PAST_MARKERS.test(text) && new RegExp(`\\b(i|you|we|they)\\s+(${COMMON_PRESENT_VERBS})\\b`, "i").test(text)) {
    signals.push({ category: "tense", suggestion: "use the past tense" });
  }
  if (AGREEMENT_SUBJECTS.test(text)) {
    signals.push({ category: "agreement", suggestion: "check the verb form" });
  }
  return signals;
}

export function serializeGrammarSignals(signals: GrammarSignal[]) {
  return [...new Set(signals.filter((signal) => signal.category === "article" || signal.category === "collocation" || signal.category === "tense" || signal.category === "agreement").map((signal) => `${signal.category}:${signal.suggestion ?? ""}`))].join("|");
}

export function parseGrammarSignals(value?: string | string[]) {
  const raw = Array.isArray(value) ? value.join("|") : value ?? "";
  return raw.split("|").flatMap((entry) => {
    const [category, suggestion] = entry.split(":");
    if (category !== "article" && category !== "collocation" && category !== "tense" && category !== "agreement") return [];
    return [{ category, suggestion: suggestion || undefined } satisfies GrammarSignal];
  });
}

export function grammarSignalCopy(signals: GrammarSignal[]) {
  if (signals.some((signal) => signal.category === "collocation")) {
    const suggestion = signals.find((signal) => signal.category === "collocation")?.suggestion;
    return suggestion ? `Try “${suggestion}” as a more natural phrase in this situation.` : "Try a more natural phrase for this situation.";
  }
  if (signals.some((signal) => signal.category === "agreement")) return "Check the verb form after he, she, or it; the subject and verb should agree.";
  if (signals.some((signal) => signal.category === "tense")) return "Because this answer refers to the past, try shifting the main verb into the past tense.";
  return "Check the small word before the next noun; a clearer article can make the phrase sound more natural.";
}
