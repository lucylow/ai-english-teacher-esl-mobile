export function nextVoiceOperation(current: number) {
  return current + 1;
}

export function isCurrentVoiceOperation(operation: number, current: number) {
  return operation === current;
}
