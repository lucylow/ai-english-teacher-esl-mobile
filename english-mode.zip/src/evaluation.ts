import type { Scenario, Skill, SkillSnapshot } from "@/src/types";

import { recommendScenario, type RecommendationOutcome } from "./recommendations";

export type EvaluationMetric = { label: string; key: keyof SkillSnapshot; value: number };

export function evaluationMetrics(scores: SkillSnapshot): EvaluationMetric[] {
  return [
    { label: "Fluency", key: "fluency", value: scores.fluency },
    { label: "Grammar", key: "grammar", value: scores.grammar },
    { label: "Vocabulary", key: "vocabulary", value: scores.vocabulary },
    { label: "Pronunciation", key: "pronunciation", value: scores.pronunciation },
  ];
}

export function nextFocusMetric(metrics: EvaluationMetric[]) {
  return metrics.reduce((lowest, metric) => metric.value < lowest.value ? metric : lowest);
}

const NEXT_PRACTICE_ACTIONS: Record<keyof SkillSnapshot, string> = {
  fluency: "Answer once without restarting; let the sentence land before you add context.",
  grammar: "Use one complete sentence with a clear time marker, such as today, yesterday, or next week.",
  vocabulary: "Replace one general word with a more precise phrase that fits the situation.",
  pronunciation: "Slow down on the key phrase and emphasize the word carrying the meaning.",
  clarity: "Lead with the main point, then add one supporting detail.",
  conversation: "Finish with a simple question or acknowledgment to keep the exchange moving.",
};

export function nextPracticeAction(metric: Pick<EvaluationMetric, "key">) {
  return NEXT_PRACTICE_ACTIONS[metric.key];
}

export function nextPracticeScenario(scenarios: Scenario[], focusSkill: Skill, currentScenarioId?: string, recentChoices: string[] = [], outcomes: Record<string, RecommendationOutcome> = {}) {
  return recommendScenario(scenarios, focusSkill, currentScenarioId, recentChoices, outcomes);
}

export function averageEvaluationScore(metrics: EvaluationMetric[]) {
  if (!metrics.length) return 0;
  return Math.round(metrics.reduce((sum, metric) => sum + metric.value, 0) / metrics.length);
}
