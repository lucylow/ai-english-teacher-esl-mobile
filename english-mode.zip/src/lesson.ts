export function lessonProgress(step: number, total: number) {
  if (total <= 0) return 0;
  return Math.max(0, Math.min(100, ((step + 1) / total) * 100));
}

export function lessonFeedback(selected: string, answer?: string) {
  if (!selected) return "";
  return selected === answer ? "That’s right." : "Keep going.";
}

export function isLessonComplete(step: number, total: number) {
  return total > 0 && step >= total - 1;
}

export function lessonScore(correct: number, total: number) {
  if (total <= 0) return 0;
  return Math.max(0, Math.min(100, Math.round((correct / total) * 100)));
}

export function lessonCompletionMessage(score: number) {
  if (score >= 80) return "You built a strong foundation today.";
  if (score >= 50) return "You made useful progress today.";
  return "You found a clear place to keep practicing.";
}
