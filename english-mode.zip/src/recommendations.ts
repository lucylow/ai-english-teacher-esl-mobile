import type { Scenario, SessionRecord, Skill } from "@/src/types";

export type RecommendationOutcome = { startedAt?: string; completedAt?: string };

export type RecommendationTrendPoint = { key: string; label: string; started: number; completed: number };

function weekStartUtc(date: Date) {
  const dayOffset = (date.getUTCDay() + 6) % 7;
  const start = new Date(date);
  start.setUTCDate(start.getUTCDate() - dayOffset);
  start.setUTCHours(0, 0, 0, 0);
  return start;
}

function trendIndex(timestamp: string | undefined, firstWeek: Date) {
  if (!timestamp) return undefined;
  const date = new Date(timestamp);
  if (Number.isNaN(date.getTime())) return undefined;
  const week = weekStartUtc(date).getTime();
  const index = Math.floor((week - firstWeek.getTime()) / (7 * 24 * 60 * 60 * 1000));
  return index >= 0 && index < 4 ? index : undefined;
}

export function recommendationOutcomeTrend(outcomes: Record<string, RecommendationOutcome>, now: Date = new Date()): RecommendationTrendPoint[] {
  const currentWeek = weekStartUtc(now);
  const firstWeek = new Date(currentWeek);
  firstWeek.setUTCDate(firstWeek.getUTCDate() - 21);
  const trend = Array.from({ length: 4 }, (_, index) => {
    const start = new Date(firstWeek);
    start.setUTCDate(start.getUTCDate() + index * 7);
    return { key: start.toISOString().slice(0, 10), label: formatRecommendationDate(start.toISOString()), started: 0, completed: 0 };
  });

  Object.values(outcomes).forEach((outcome) => {
    const startedIndex = trendIndex(outcome.startedAt, firstWeek);
    const completedIndex = trendIndex(outcome.completedAt, firstWeek);
    if (startedIndex !== undefined) trend[startedIndex].started += 1;
    if (completedIndex !== undefined) trend[completedIndex].completed += 1;
  });
  return trend;
}

export function updateRecommendationOutcome(history: Record<string, RecommendationOutcome>, scenarioId: string, event: "started" | "completed", timestamp: string) {
  if (!scenarioId || !timestamp) return history;
  const current = history[scenarioId] ?? {};
  return { ...history, [scenarioId]: { ...current, ...(event === "started" ? { startedAt: timestamp } : { completedAt: timestamp }) } };
}

export function latestCompletedRecommendationScore(outcomes: Record<string, RecommendationOutcome>, sessions: SessionRecord[]) {
  const id = latestCompletedRecommendationId(outcomes);
  if (!id) return undefined;
  const session = sessions.find((item) => item.scenarioId === id);
  return session ? Math.max(0, Math.min(100, Math.round(session.score))) : undefined;
}

export function formatRecommendationDate(timestamp?: string) {
  if (!timestamp) return "Recently";
  const date = new Date(timestamp);
  if (Number.isNaN(date.getTime())) return "Recently";
  const months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
  return `${months[date.getUTCMonth()]} ${date.getUTCDate()}`;
}

export function latestCompletedRecommendationId(outcomes: Record<string, RecommendationOutcome>) {
  return Object.entries(outcomes)
    .filter(([, outcome]) => Boolean(outcome.completedAt))
    .sort(([, a], [, b]) => (b.completedAt ?? "").localeCompare(a.completedAt ?? ""))[0]?.[0];
}

export function recommendationOutcomeLabel(outcome?: RecommendationOutcome) {
  if (outcome?.completedAt) return "Revisit for confidence";
  if (outcome?.startedAt) return "In progress";
  return "New practice";
}

export function recommendScenarios(scenarios: Scenario[], focusSkill: Skill, excludedId?: string, limit = 3, recentChoices: string[] = [], outcomes: Record<string, RecommendationOutcome> = {}) {
  const available = scenarios.filter((scenario) => scenario.id !== excludedId);
  const recent = new Set(recentChoices);
  const targeted = available.filter((scenario) => scenario.targetSkills.includes(focusSkill));
  const fallback = available.filter((scenario) => !scenario.targetSkills.includes(focusSkill));
  const rank = (scenario: Scenario) => (outcomes[scenario.id]?.completedAt ? 2 : recent.has(scenario.id) ? 1 : 0);
  return [...targeted.sort((a, b) => rank(a) - rank(b)), ...fallback.sort((a, b) => rank(a) - rank(b))].slice(0, Math.max(0, limit));
}

export function recommendScenario(scenarios: Scenario[], focusSkill: Skill, excludedId?: string, recentChoices: string[] = [], outcomes: Record<string, RecommendationOutcome> = {}) {
  return recommendScenarios(scenarios, focusSkill, excludedId, 1, recentChoices, outcomes)[0];
}
