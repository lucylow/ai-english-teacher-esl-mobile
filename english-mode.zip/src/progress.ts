import type { SessionRecord, Skill } from "@/src/types";

const FOCUS_GUIDANCE: Record<Skill, { title: string; body: string }> = {
  fluency: { title: "Keep the answer moving", body: "Give one example before searching for the perfect word, so your ideas keep their rhythm." },
  grammar: { title: "Make each thought land", body: "Slow down at sentence turns and finish each thought with a clear, simple structure." },
  vocabulary: { title: "Make explanations richer", body: "Use one new connector to make longer explanations easier to follow." },
  pronunciation: { title: "Choose clarity over speed", body: "Aim for clear word endings and a steady pace rather than trying to speak faster." },
  clarity: { title: "Lead with your main point", body: "Start with the idea, then add one reason or example to make your meaning easier to follow." },
  conversation: { title: "Leave room for connection", body: "Add a simple reaction or question so your answer naturally invites the other person in." },
};

export function formatSkillLabel(skill: Skill) {
  return skill.charAt(0).toUpperCase() + skill.slice(1);
}

export function focusGuidance(skill: Skill) {
  return FOCUS_GUIDANCE[skill];
}

function safeSessionScore(score: number) {
  return Number.isFinite(score) ? Math.max(0, Math.min(100, Math.round(score))) : undefined;
}

export function scoreContext(sessions: SessionRecord[]) {
  const latest = [...sessions]
    .filter((session) => safeSessionScore(session.score) !== undefined && !Number.isNaN(new Date(session.completedAt).getTime()))
    .sort((a, b) => b.completedAt.localeCompare(a.completedAt))[0];
  if (!latest) return { headline: "Current score", detail: "Complete a rehearsal to start a personal comparison." };
  return { headline: `Latest rehearsal · ${safeSessionScore(latest.score)}`, detail: "Your Power Score blends six speaking skills across recent practice." };
}
