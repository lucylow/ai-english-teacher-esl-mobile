import type { CoachingSignalSettings } from "./types";

export const DEFAULT_COACHING_SETTINGS: CoachingSignalSettings = { fillers: true, grammar: true };

export function normalizeCoachingSettings(value: unknown): CoachingSignalSettings {
  if (!value || typeof value !== "object") return DEFAULT_COACHING_SETTINGS;
  const candidate = value as Partial<CoachingSignalSettings>;
  return {
    fillers: candidate.fillers !== false,
    grammar: candidate.grammar !== false,
  };
}

export function coachingSignalEnabled(settings: CoachingSignalSettings, signal: keyof CoachingSignalSettings) {
  return settings[signal];
}

export function isDefaultCoachingSettings(settings: CoachingSignalSettings) {
  return settings.fillers && settings.grammar;
}
