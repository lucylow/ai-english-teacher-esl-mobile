import type { LearningProfile } from "@/src/types";

export type OnboardingStep = "welcome" | "goal" | "level" | "interests" | "duration";

export type OnboardingDraft = {
  step: number;
  goal: string;
  level: string;
  interests: string[];
  preferredDuration: number;
};

export const ONBOARDING_STEPS: { key: OnboardingStep; eyebrow: string; title: string; body: string }[] = [
  { key: "welcome", eyebrow: "A DIFFERENT WAY TO LEARN", title: "Practice the English you’ll actually need.", body: "ENGLISH MODE turns tomorrow’s real-life situations into speaking practice today." },
  { key: "goal", eyebrow: "YOUR STARTING POINT", title: "What do you want to feel ready for?", body: "Choose the situation that matters most right now. You can change it anytime." },
  { key: "level", eyebrow: "NO TEST REQUIRED", title: "Where does English feel comfortable today?", body: "Pick the description that sounds most like you. This only helps us set the right starting pace." },
  { key: "interests", eyebrow: "MAKE IT YOURS", title: "What would you enjoy talking about?", body: "Choose up to three topics. They’ll shape examples and scenarios in your future rehearsals." },
  { key: "duration", eyebrow: "A RHYTHM YOU CAN KEEP", title: "How much time feels realistic?", body: "A small, repeatable practice habit is more useful than an ambitious plan you cannot keep." },
];

export const GOAL_OPTIONS = ["Everyday conversation", "Presentations", "Interviews", "Travel", "Work", "Social confidence"] as const;
export const LEVEL_OPTIONS = [
  { value: "Getting started", detail: "I can use a few phrases, but I need time to form answers." },
  { value: "Finding my flow", detail: "I can communicate, but I want to sound more natural and confident." },
  { value: "Ready to stretch", detail: "I can hold conversations and want sharper, more precise English." },
] as const;
export const INTEREST_OPTIONS = ["Technology", "Music", "Travel", "Movies", "Business", "Food"] as const;
export const DURATION_OPTIONS = [5, 10, 15] as const;

export const DEFAULT_ONBOARDING_DRAFT: OnboardingDraft = {
  step: 0,
  goal: GOAL_OPTIONS[1],
  level: LEVEL_OPTIONS[1].value,
  interests: [INTEREST_OPTIONS[0]],
  preferredDuration: 10,
};

export function normalizeOnboardingDraft(value: unknown): OnboardingDraft {
  if (!value || typeof value !== "object") return DEFAULT_ONBOARDING_DRAFT;
  const candidate = value as Partial<OnboardingDraft>;
  const step = typeof candidate.step === "number" && Number.isInteger(candidate.step) ? Math.max(0, Math.min(ONBOARDING_STEPS.length - 1, candidate.step)) : 0;
  const goal = typeof candidate.goal === "string" && GOAL_OPTIONS.includes(candidate.goal as (typeof GOAL_OPTIONS)[number]) ? candidate.goal : DEFAULT_ONBOARDING_DRAFT.goal;
  const level = typeof candidate.level === "string" && LEVEL_OPTIONS.some((option) => option.value === candidate.level) ? candidate.level : DEFAULT_ONBOARDING_DRAFT.level;
  const interests = Array.isArray(candidate.interests) ? candidate.interests.filter((item): item is string => typeof item === "string" && INTEREST_OPTIONS.includes(item as (typeof INTEREST_OPTIONS)[number])).slice(0, 3) : DEFAULT_ONBOARDING_DRAFT.interests;
  const preferredDuration = typeof candidate.preferredDuration === "number" && DURATION_OPTIONS.includes(candidate.preferredDuration as (typeof DURATION_OPTIONS)[number]) ? candidate.preferredDuration : DEFAULT_ONBOARDING_DRAFT.preferredDuration;
  return { step, goal, level, interests: interests.length ? interests : DEFAULT_ONBOARDING_DRAFT.interests, preferredDuration };
}

export function canAdvanceOnboarding(step: number, draft: OnboardingDraft) {
  if (step === 0) return true;
  if (step === 1) return GOAL_OPTIONS.includes(draft.goal as (typeof GOAL_OPTIONS)[number]);
  if (step === 2) return LEVEL_OPTIONS.some((option) => option.value === draft.level);
  if (step === 3) return draft.interests.length >= 1 && draft.interests.length <= 3;
  if (step === 4) return DURATION_OPTIONS.includes(draft.preferredDuration as (typeof DURATION_OPTIONS)[number]);
  return false;
}

export function profilePatchFromOnboarding(draft: OnboardingDraft): Partial<LearningProfile> {
  return { goal: draft.goal, level: draft.level, interests: draft.interests, preferredDuration: draft.preferredDuration };
}
