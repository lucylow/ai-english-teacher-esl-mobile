export type TeachingMode = "explain" | "guide" | "practice" | "review" | "assess";
export interface TeachingObjective { id: string; skill: string; statement: string; threshold: number; }
export const hints = ["Think about the subject.", "Choose the time frame.", "Say the complete sentence."];
export const debrief = ["What went well?", "What was difficult?", "What will you change?"];
export const confidenceLabels = ["Not yet", "A little", "Mostly", "Confident"];
export function teachingMode(score: number): TeachingMode { return score < 45 ? "explain" : score < 70 ? "guide" : score < 90 ? "practice" : "review"; }
export function progress(index: number, total: number) { return total ? Math.round(((index + 1) / total) * 100) : 0; }
export function guidedPractice(skill: string) { return [`Start one ${skill} example.`, "Add one detail.", "Explain why."]; }
export function independentPractice(skill: string) { return `Use ${skill} without a sentence starter.`; }
export function repairError(original: string, corrected: string) { return { notice: original, model: corrected, practice: `Use: ${corrected}` }; }
export function feedback(correct: boolean, next: string) { return correct ? "Correct. Use it once more." : `Try ${next}`; }
export function transfer(skill: string) { return `Use ${skill} in a new situation.`; }
export function teachingStyle(confidence: number, mastery: number) { return confidence < 40 ? "supportive" : mastery > 85 ? "challenging" : "balanced"; }
