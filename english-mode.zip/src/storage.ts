export type KeyValueStorage = { getItem(key: string): Promise<string | null>; setItem(key: string, value: string): Promise<void>; removeItem(key: string): Promise<void>; };

export type StorageResult<T> = { ok: true; value: T } | { ok: false; error: Error };

export async function safeGet<T>(storage: KeyValueStorage, key: string, fallback: T): Promise<StorageResult<T>> { try { const raw = await storage.getItem(key); if (!raw) return { ok: true, value: fallback }; try { return { ok: true, value: JSON.parse(raw) as T }; } catch { return { ok: false, error: new Error("STORAGE_INVALID_DATA") }; } } catch (error) { return { ok: false, error: error instanceof Error ? error : new Error("STORAGE_READ_FAILED") }; } }

export async function safeSet(storage: KeyValueStorage, key: string, value: unknown): Promise<StorageResult<void>> { try { await storage.setItem(key, JSON.stringify(value)); return { ok: true, value: undefined }; } catch (error) { return { ok: false, error: error instanceof Error ? error : new Error("STORAGE_WRITE_FAILED") }; } }

export async function safeRemove(storage: KeyValueStorage, key: string): Promise<StorageResult<void>> { try { await storage.removeItem(key); return { ok: true, value: undefined }; } catch (error) { return { ok: false, error: error instanceof Error ? error : new Error("STORAGE_DELETE_FAILED") }; } }
