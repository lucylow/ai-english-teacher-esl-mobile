export const motionConfig = { fast: 120, standard: 220, entrance: 280 } as const;
