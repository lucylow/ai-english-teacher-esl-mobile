import { z } from "zod";
import type { Scenario } from "./types";

export const PROMPTS = { conversation: "conversation.v5", evaluation: "evaluation.v4", scenario: "scenario.v3" } as const;
const EMAIL = /\b[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}\b/gi;
const PHONE = /\+?\d[\d\s().-]{7,}\d/g;
export function scrubAIInput(text: string) { return text.replace(EMAIL, "[email removed]").replace(PHONE, "[phone removed]").slice(0, 3000); }
export function adjustDifficulty(args: { completionRate: number; pauseSeconds: number; recentSuccesses: number }) { if (args.completionRate < 0.45 || args.pauseSeconds > 8) return "down" as const; if (args.completionRate > 0.85 && args.recentSuccesses >= 3) return "up" as const; return "same" as const; }
const TutorResponseSchema = z.object({ message: z.string().min(1).max(1000), followUp: z.string().max(400).optional() });
export function parseTutorResponse(raw: unknown) { const parsed = TutorResponseSchema.safeParse(raw); return parsed.success ? parsed.data : { message: "Tell me a little more about that.", followUp: "Why do you think so?" }; }
export interface AIProvider { chat(input: { messages: { role: string; content: string }[] }): Promise<{ text: string }>; generateScenario(input: { goal: string; level: string; interests: string[] }): Promise<Scenario>; }
export class MockAIProvider implements AIProvider { async chat(input: { messages: { role: string; content: string }[] }) { const last = input.messages.at(-1)?.content ?? "that"; return { text: `That’s interesting. Tell me more about ${scrubAIInput(last).slice(0, 80)}.` }; } async generateScenario(): Promise<Scenario> { return { id: "generated", title: "Explain something you know", category: "Custom", context: "Share an idea from your day with a curious conversation partner.", objective: "Practice clear explanations and follow-up questions.", difficulty: "comfortable", estimatedMinutes: 6, openingLine: "What would you like to explain today?", targetSkills: ["fluency", "clarity"] }; } }
