export type Skill = "fluency" | "grammar" | "vocabulary" | "pronunciation" | "clarity" | "conversation";
export type Difficulty = "easy" | "comfortable" | "stretch";
export type TutorTone = "supportive" | "balanced" | "challenging";

export interface SkillSnapshot {
  fluency: number;
  grammar: number;
  vocabulary: number;
  pronunciation: number;
  clarity: number;
  conversation: number;
}

export interface LearnerMemorySettings { enabled: boolean; saveMistakes: boolean; savePreferences: boolean; saveAudio: boolean; }
export interface CoachingSignalSettings { fillers: boolean; grammar: boolean; }

export interface RehearsalDraft { scenarioId: string; transcript: string[]; elapsedSeconds: number; updatedAt: string; }

export interface DashboardData { powerScore: number; weeklyDelta: number; focusSkill: Skill; dailyMission: { title: string; subtitle: string; scenarioId: string }; streak: number; }

export interface LearningProfile {
  firstName: string;
  goal: string;
  level: string;
  interests: string[];
  preferredDuration: number;
  tone: TutorTone;
  skills: SkillSnapshot;
  focusSkill: Skill;
  streak: number;
  onboardingComplete: boolean;
  memorySettings?: LearnerMemorySettings;
  coachingSettings?: CoachingSignalSettings;
  memoryNotes?: string[];
  recommendationHistory?: string[];
  recommendationOutcomes?: Record<string, { startedAt?: string; completedAt?: string }>;
}

export interface Scenario {
  id: string;
  title: string;
  category: string;
  context: string;
  objective: string;
  difficulty: Difficulty;
  estimatedMinutes: number;
  openingLine: string;
  targetSkills: Skill[];
  coachCue?: string;
  premium?: boolean;
}

export interface TranscriptTurn {
  id: string;
  role: "user" | "assistant";
  text: string;
  createdAt: string;
  confidence?: number;
}

export interface Evaluation {
  id: string;
  scenarioId: string;
  scores: SkillSnapshot;
  improvements: { title: string; detail: string; example?: string }[];
  completedAt: string;
}

export interface SessionRecord {
  id: string;
  scenarioId: string;
  scenarioTitle: string;
  score: number;
  completedAt: string;
  durationSeconds: number;
}

export interface AppState {
  profile: LearningProfile;
  scenarios: Scenario[];
  sessions: SessionRecord[];
  evaluations: Evaluation[];
  hasHydrated: boolean;
  rehearsalDraft?: RehearsalDraft;
}
