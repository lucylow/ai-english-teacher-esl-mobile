const environment = process.env.EXPO_PUBLIC_ENV ?? "development";

export const appConfig = { environment, apiUrl: process.env.EXPO_PUBLIC_API_URL ?? "", mockMode: process.env.EXPO_PUBLIC_MOCK_MODE === "true" || environment === "development" } as const;

export function assertNoMocksInProduction(config = appConfig) { if (config.environment === "production" && config.mockMode) throw new Error("MOCK_MODE_FORBIDDEN_IN_PRODUCTION"); }

export function canUseRemoteData(config = appConfig) { return Boolean(config.apiUrl) && !config.mockMode; }
