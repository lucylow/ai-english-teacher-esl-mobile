import React from "react";
import { Pressable, StyleSheet, Text, View, type PressableProps, type StyleProp, type TextStyle, type ViewStyle } from "react-native";
export const palette = { canvas: "#F7F4EF", surface: "#FFFCF8", charcoal: "#1E2328", slate: "#6D747B", border: "#E7E1D8", coral: "#F06A5E", coralDark: "#C94E45", sage: "#B8CBB8", gold: "#D9A441", blue: "#5E81AC", error: "#C94B4B" };

export function Eyebrow({ children }: { children: React.ReactNode }) { return <Text style={styles.eyebrow}>{children}</Text>; }
export function Title({ children, style }: { children: React.ReactNode; style?: TextStyle }) { return <Text style={[styles.title, style]}>{children}</Text>; }
export function Body({ children, style }: { children: React.ReactNode; style?: TextStyle }) { return <Text style={[styles.body, style]}>{children}</Text>; }
export function Card({ children, style }: { children: React.ReactNode; style?: object }) { return <View style={[styles.card, style]}>{children}</View>; }
export function PrimaryButton({ children, style, labelStyle, ...props }: Omit<PressableProps, "style"> & { children: React.ReactNode; style?: StyleProp<ViewStyle>; labelStyle?: StyleProp<TextStyle> }) { return <Pressable accessibilityRole="button" {...props} style={({ pressed }) => [styles.primaryButton, style, pressed && styles.pressed]}><Text style={[styles.primaryLabel, labelStyle]}>{children}</Text></Pressable>; }
export function SecondaryButton({ children, style, labelStyle, ...props }: Omit<PressableProps, "style"> & { children: React.ReactNode; style?: StyleProp<ViewStyle>; labelStyle?: StyleProp<TextStyle> }) { return <Pressable accessibilityRole="button" {...props} style={({ pressed }) => [styles.secondaryButton, style, pressed && styles.pressed]}><Text style={[styles.secondaryLabel, labelStyle]}>{children}</Text></Pressable>; }
export function ProgressBar({ value, color = palette.coral }: { value: number; color?: string }) { return <View style={styles.progressTrack}><View style={[styles.progressFill, { width: `${Math.min(100, value)}%`, backgroundColor: color }]} /></View>; }
export function ScoreRing({ score, size = 128 }: { score: number; size?: number }) { return <View accessibilityLabel={`Score ${score} out of 100`} style={[styles.ring, { width: size, height: size, borderRadius: size / 2 }]}><Text style={[styles.ringScore, { fontSize: size * 0.31 }]}>{score}</Text><Text style={styles.ringCaption}>POWER</Text></View>; }
export function SectionHeader({ title, action, onAction }: { title: string; action?: string; onAction?: () => void }) { return <View style={styles.sectionHeader}><Text style={styles.sectionTitle}>{title}</Text>{action && <Pressable onPress={onAction} accessibilityRole="button"><Text style={styles.sectionAction}>{action}</Text></Pressable>}</View>; }
export function Chip({ children, active = false }: { children: React.ReactNode; active?: boolean }) { return <View style={[styles.chip, active && styles.chipActive]}><Text style={[styles.chipText, active && styles.chipTextActive]}>{children}</Text></View>; }
export function Avatar({ label = "EM" }: { label?: string }) { return <View style={styles.avatar}><Text style={styles.avatarText}>{label}</Text></View>; }

export const styles = StyleSheet.create({
  eyebrow: { color: palette.coralDark, fontSize: 12, fontWeight: "800", letterSpacing: 1.5, textTransform: "uppercase", lineHeight: 18 },
  title: { color: palette.charcoal, fontSize: 32, fontWeight: "800", letterSpacing: -0.7, lineHeight: 38 },
  body: { color: palette.slate, fontSize: 16, lineHeight: 24 },
  card: { backgroundColor: palette.surface, borderColor: palette.border, borderWidth: 1, borderRadius: 24, padding: 20 },
  primaryButton: { alignItems: "center", justifyContent: "center", minHeight: 54, paddingHorizontal: 22, borderRadius: 16, backgroundColor: palette.coral },
  primaryLabel: { color: "#FFFFFF", fontSize: 16, fontWeight: "800", letterSpacing: 0.1 },
  secondaryButton: { alignItems: "center", justifyContent: "center", minHeight: 50, paddingHorizontal: 20, borderRadius: 15, borderWidth: 1, borderColor: palette.border, backgroundColor: palette.surface },
  secondaryLabel: { color: palette.charcoal, fontSize: 15, fontWeight: "700" },
  pressed: { opacity: 0.8, transform: [{ scale: 0.98 }] },
  progressTrack: { height: 8, borderRadius: 8, backgroundColor: "#E9E4DC", overflow: "hidden" },
  progressFill: { height: 8, borderRadius: 8 },
  ring: { alignItems: "center", justifyContent: "center", borderWidth: 10, borderColor: palette.coral, backgroundColor: palette.surface },
  ringScore: { color: palette.charcoal, fontWeight: "800", letterSpacing: -1 },
  ringCaption: { color: palette.slate, fontSize: 9, fontWeight: "800", letterSpacing: 1.2, marginTop: 1 },
  sectionHeader: { flexDirection: "row", alignItems: "center", justifyContent: "space-between", marginBottom: 12 },
  sectionTitle: { color: palette.charcoal, fontSize: 18, fontWeight: "800" },
  sectionAction: { color: palette.coralDark, fontSize: 14, fontWeight: "800" },
  chip: { paddingHorizontal: 10, paddingVertical: 6, borderRadius: 20, backgroundColor: "#F0ECE5" },
  chipActive: { backgroundColor: palette.charcoal },
  chipText: { color: palette.slate, fontSize: 12, fontWeight: "700" },
  chipTextActive: { color: "#FFFFFF" },
  avatar: { width: 44, height: 44, borderRadius: 22, alignItems: "center", justifyContent: "center", backgroundColor: palette.charcoal },
  avatarText: { color: "#FFFFFF", fontWeight: "800", fontSize: 13 },
});
