import type { Scenario, Skill } from "@/src/types";

const skillLabels: Record<Skill, string> = {
  fluency: "fluency",
  grammar: "grammar",
  vocabulary: "vocabulary",
  pronunciation: "pronunciation",
  clarity: "clarity",
  conversation: "conversation",
};

export function recommendationRationale(scenario: Scenario, focusSkill: Skill) {
  const skill = skillLabels[focusSkill];
  if (scenario.targetSkills.includes(focusSkill)) return `This scenario gives you a practical way to strengthen your ${skill}.`;
  return `This scenario keeps your speaking practice varied while you build ${skill}.`;
}

export function recommendationOutcomeRationale(outcome?: { startedAt?: string; completedAt?: string }) {
  if (outcome?.completedAt) return "A calm revisit can help turn this skill into confidence.";
  if (outcome?.startedAt) return "Pick up where you left off when you are ready.";
  return "A fresh situation gives you a low-pressure place to begin.";
}
