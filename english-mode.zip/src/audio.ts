import { createAudioPlayer, setAudioModeAsync, type AudioPlayer } from "expo-audio";

export interface PlaybackHandle { play: () => void; pause: () => void; stop: () => void; remove: () => void; }

export async function configurePlayback() { await setAudioModeAsync({ playsInSilentMode: true, allowsRecording: false }); }

export function createSafePlayback(source?: string): PlaybackHandle { let player: AudioPlayer | null = null; if (source) { try { player = createAudioPlayer(source); } catch { player = null; } } return { play: () => player?.play(), pause: () => player?.pause(), stop: () => { player?.pause(); player?.seekTo(0); }, remove: () => { player?.remove(); player = null; } }; }
