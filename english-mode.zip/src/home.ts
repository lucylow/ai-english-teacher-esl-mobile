import type { DashboardData } from "@/src/types";

export type HomePracticeTarget = { kind: "session"; scenarioId: string } | { kind: "practice" };

export function homePracticeTarget(dashboard?: Pick<DashboardData, "dailyMission">): HomePracticeTarget {
  const scenarioId = dashboard?.dailyMission?.scenarioId?.trim();
  return scenarioId ? { kind: "session", scenarioId } : { kind: "practice" };
}
