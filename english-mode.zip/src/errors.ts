export type AppErrorCode = "offline" | "timeout" | "unauthorized" | "quota" | "server" | "invalid-response" | "unknown";

export class AppError extends Error { constructor(public readonly code: AppErrorCode, message: string, public readonly retryable = false) { super(message); this.name = "AppError"; } }

export function isRetryableError(error: unknown) { return normalizeError(error).retryable; }

export function assertJsonResponse<T>(value: unknown): T { if (value === null || value === undefined) throw new AppError("invalid-response", "We received an unexpected response.", true); return value as T; }

export function normalizeError(error: unknown): AppError { if (error instanceof AppError) return error; const message = error instanceof Error ? error.message : String(error); if (/abort|timeout/i.test(message)) return new AppError("timeout", "The request took too long.", true); if (/network|offline|failed to fetch/i.test(message)) return new AppError("offline", "You appear to be offline.", true); if (/401|403|unauthorized/i.test(message)) return new AppError("unauthorized", "Please sign in again to continue."); if (/429|quota|limit/i.test(message)) return new AppError("quota", "You’ve reached the current usage limit."); if (/HTTP_5|server/i.test(message)) return new AppError("server", "The service is unavailable right now.", true); if (/json|parse|response/i.test(message)) return new AppError("invalid-response", "We received an unexpected response.", true); return new AppError("unknown", "Something went wrong. Please try again.", true); }
