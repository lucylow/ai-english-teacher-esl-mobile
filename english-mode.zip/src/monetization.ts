export type PlanId = "free" | "monthly" | "annual" | "lifetime";
export type Entitlement = "pro" | "advanced_ai" | "voice_unlimited" | "history";
export interface MonetizationProfile { userId: string; plan: PlanId; entitlements: Entitlement[]; renewsAt?: string; }
export interface Plan { id: PlanId; title: string; priceLabel: string; productId: string; annual: boolean; features: string[]; featured?: boolean; }
export const FREE_LIMITS = { aiTurnsPerWeek: 12, customScenariosPerWeek: 2, deepEvaluationsPerWeek: 2, voiceMinutesPerWeek: 20, historyDays: 7 } as const;
export const MOCK_PLANS: Plan[] = [
  { id: "monthly", title: "Monthly", priceLabel: "$7.99 / month", productId: "english_mode_monthly", annual: false, features: ["Unlimited rehearsals", "Advanced pronunciation", "Personalized curriculum"] },
  { id: "annual", title: "Yearly", priceLabel: "$49.99 / year", productId: "english_mode_annual", annual: true, featured: true, features: ["Everything in Pro", "Best value", "Progress comparisons"] },
  { id: "lifetime", title: "Lifetime", priceLabel: "$99.99 once", productId: "english_mode_lifetime", annual: false, features: ["One payment", "Unlimited access"] },
];
export interface SubscriptionService { getOfferings(): Promise<Plan[]>; purchase(productId: string): Promise<MonetizationProfile>; restorePurchases(): Promise<MonetizationProfile>; }
export class MockBillingProvider implements SubscriptionService { async getOfferings() { return MOCK_PLANS; } async purchase(productId: string) { const plan = MOCK_PLANS.find((item) => item.productId === productId); return { userId: "demo", plan: plan?.id ?? "monthly", entitlements: ["pro", "advanced_ai", "voice_unlimited", "history"] as Entitlement[] }; } async restorePurchases() { return { userId: "demo", plan: "free" as PlanId, entitlements: [] as Entitlement[] }; } }
export function hasEntitlement(entitlements: string[], value: Entitlement) { return entitlements.includes(value); }
export function selectBestPlan(plans: Plan[]) { return plans.find((plan) => plan.annual && plan.featured) ?? plans.find((plan) => plan.annual) ?? plans[0]; }

export interface Product { id: PlanId; title: string; price: string; period?: string; }
export interface CustomerEntitlements { active: Entitlement[]; expiresAt?: string; }
export type SubscriptionState = "active" | "canceled" | "expired" | "trial" | "pending";
export interface BillingService { getProducts(): Promise<Product[]>; purchase(productId: PlanId): Promise<CustomerEntitlements>; restore(): Promise<CustomerEntitlements>; getEntitlements(): Promise<CustomerEntitlements>; manageSubscription(): Promise<void>; }
export const PRODUCT_CATALOG: Product[] = MOCK_PLANS.map((plan) => ({ id: plan.id, title: plan.title, price: plan.priceLabel, period: plan.id === "monthly" ? "month" : plan.id === "annual" ? "year" : undefined }));
export function hasProAccess(state?: CustomerEntitlements) { return Boolean(state?.active.includes("pro") || state?.active.includes("advanced_ai")); }
export function trialDaysLeft(expiresAt?: string, now = Date.now()) { if (!expiresAt) return 0; return Math.max(0, Math.ceil((new Date(expiresAt).getTime() - now) / 86_400_000)); }
export function isSubscriptionActive(state: SubscriptionState) { return state === "active" || state === "trial"; }
export function usagePercent(used: number, limit: number) { return Math.min(1, Math.max(0, used / Math.max(1, limit))); }
export class DevelopmentBillingProvider implements BillingService { async getProducts() { return PRODUCT_CATALOG; } async purchase() { return { active: ["pro", "advanced_ai", "voice_unlimited", "history"] as Entitlement[] }; } async restore() { return { active: [] as Entitlement[] }; } async getEntitlements() { return { active: [] as Entitlement[] }; } async manageSubscription() { return undefined; } }
