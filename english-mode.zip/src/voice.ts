export type VoiceState = "idle" | "permission" | "recording" | "processing" | "playing" | "error";
export interface TranscriptResult { text: string; confidence: number; durationMs: number; language: string; }
export interface SpeechToTextProvider { start(language: string): Promise<void>; stop(): Promise<TranscriptResult>; cancel(): Promise<void>; }
export interface PronunciationProvider { analyze(input: { audioUri?: string; expectedText?: string; language: string }): Promise<{ score: number; confidence: number; issues: string[] }>; }
export class MockSpeechToTextProvider implements SpeechToTextProvider { private active = false; async start() { this.active = true; } async stop() { this.active = false; return { text: "I think this idea could help people because it is practical and easy to use.", confidence: 0.95, durationMs: 4800, language: "en-US" }; } async cancel() { this.active = false; } }
export class MockPronunciationProvider implements PronunciationProvider { async analyze() { return { score: 78, confidence: 0.84, issues: ["Practice the r sound in longer words."] }; } }
export async function requestMicrophonePermission() { return true; }
export function responseLatencyScore(seconds: number) { if (seconds <= 1.5) return 95; if (seconds <= 3) return 85; if (seconds <= 5) return 75; if (seconds <= 8) return 60; return 45; }
