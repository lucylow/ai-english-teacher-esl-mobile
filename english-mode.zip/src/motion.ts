import { AccessibilityInfo, Easing } from "react-native";
import { motionConfig } from "@/src/motion-config";

export const motion = { ...motionConfig, ease: Easing.out(Easing.cubic) } as const;

export async function getReducedMotionEnabled() { return AccessibilityInfo.isReduceMotionEnabled(); }
