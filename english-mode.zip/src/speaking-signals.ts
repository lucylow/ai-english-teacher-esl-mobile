const FILLER_WORDS = ["um", "uh", "like", "you know"] as const;

export type FillerWord = (typeof FILLER_WORDS)[number];

export function detectFillerWords(turns: string[]): FillerWord[] {
  const text = turns.join(" ").toLowerCase();
  return FILLER_WORDS.filter((filler) => new RegExp(`\\b${filler.replace(" ", "\\s+")}\\b`, "i").test(text));
}

export function serializeFillerWords(fillers: string[]) {
  return fillers.filter((filler): filler is FillerWord => FILLER_WORDS.includes(filler as FillerWord)).join(",");
}

export function parseFillerWords(value?: string | string[]) {
  const raw = Array.isArray(value) ? value.join(",") : value ?? "";
  return raw.split(",").filter((filler): filler is FillerWord => FILLER_WORDS.includes(filler as FillerWord));
}

export function fillerCoachingCopy(fillers: string[]) {
  if (!fillers.length) return "A short pause can give your next answer more space.";
  const joined = fillers.join(", ");
  return `A short pause can replace ${joined} and help your next answer sound more deliberate.`;
}
