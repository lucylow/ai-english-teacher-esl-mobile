import AsyncStorage from "@react-native-async-storage/async-storage";
import React, { createContext, useContext, useEffect, useMemo, useState } from "react";
import { safeGet, safeSet } from "../storage";
import { evaluations as seedEvaluations, scenarios as seedScenarios, sessions as seedSessions, starterProfile } from "../data/mock";
import type { AppState, Evaluation, LearningProfile, RehearsalDraft, Scenario, SessionRecord } from "../types";
import { updateRecommendationOutcome } from "../recommendations";

const STORAGE_KEY = "english-mode-state-v1";

type AppContextValue = AppState & {
  updateProfile: (patch: Partial<LearningProfile>) => void;
  completeOnboarding: (patch: Partial<LearningProfile>) => void;
  addSession: (session: SessionRecord, evaluation: Evaluation) => void;
  addLessonCompletion: (completion: { title: string; score: number; durationSeconds: number }) => void;
  getScenario: (id: string) => Scenario | undefined;
  saveRehearsalDraft: (draft: RehearsalDraft) => void;
  clearRehearsalDraft: () => void;
  setMemoryEnabled: (enabled: boolean) => void;
  clearMemory: () => void;
  recordRecommendationChoice: (scenarioId: string) => void;
  clearRecommendationHistory: () => void;
  removeRecommendationChoice: (scenarioId: string) => void;
  restoreRecommendationChoice: (scenarioId: string) => void;
  recordRecommendationStarted: (scenarioId: string) => void;
  recordRecommendationCompleted: (scenarioId: string) => void;
};

const AppContext = createContext<AppContextValue | null>(null);

export function AppProvider({ children }: { children: React.ReactNode }) {
  const [profile, setProfile] = useState(starterProfile);
  const [scenarioData] = useState(seedScenarios);
  const [sessionData, setSessionData] = useState(seedSessions);
  const [evaluationData, setEvaluationData] = useState(seedEvaluations);
  const [rehearsalDraft, setRehearsalDraft] = useState<RehearsalDraft | undefined>(undefined);
  const [hasHydrated, setHasHydrated] = useState(false);

  useEffect(() => { let active = true; void safeGet<Partial<AppState>>(AsyncStorage, STORAGE_KEY, {}).then((result) => { if (!active) return; if (result.ok) { const saved = result.value; if (saved.profile) setProfile(saved.profile); if (saved.sessions) setSessionData(saved.sessions); if (saved.evaluations) setEvaluationData(saved.evaluations); if (saved.rehearsalDraft) setRehearsalDraft(saved.rehearsalDraft); } setHasHydrated(true); }); return () => { active = false; }; }, []);

  useEffect(() => { if (!hasHydrated) return; let active = true; void safeSet(AsyncStorage, STORAGE_KEY, { profile, sessions: sessionData, evaluations: evaluationData, rehearsalDraft }).then(() => { if (!active) return; }); return () => { active = false; }; }, [profile, sessionData, evaluationData, rehearsalDraft, hasHydrated]);

  const value = useMemo<AppContextValue>(() => ({
    profile, scenarios: scenarioData, sessions: sessionData, evaluations: evaluationData, hasHydrated, rehearsalDraft,
    updateProfile: (patch) => setProfile((current) => ({ ...current, ...patch })),
    completeOnboarding: (patch) => setProfile((current) => ({ ...current, ...patch, onboardingComplete: true })),
    addSession: (session, evaluation) => { setSessionData((current) => [session, ...current]); setEvaluationData((current) => [evaluation, ...current]); setProfile((current) => { const skills = { ...current.skills }; (Object.keys(skills) as (keyof typeof skills)[]).forEach((skill) => { skills[skill] = Math.round(skills[skill] * 0.7 + evaluation.scores[skill] * 0.3); }); const focusSkill = (Object.keys(skills) as (keyof typeof skills)[]).sort((a, b) => skills[a] - skills[b])[0]; return { ...current, skills, focusSkill, streak: current.streak + 1, recommendationOutcomes: current.memorySettings?.enabled === false ? current.recommendationOutcomes : updateRecommendationOutcome(current.recommendationOutcomes ?? {}, session.scenarioId, "completed", session.completedAt) }; }); },
    addLessonCompletion: (completion) => setSessionData((current) => [{ id: `lesson-${Date.now()}`, scenarioId: "guided-lesson", scenarioTitle: completion.title, score: Math.max(0, Math.min(100, Math.round(completion.score))), completedAt: new Date().toISOString(), durationSeconds: completion.durationSeconds }, ...current]),
    getScenario: (id) => scenarioData.find((scenario) => scenario.id === id),
    saveRehearsalDraft: (draft) => setRehearsalDraft(draft),
    clearRehearsalDraft: () => setRehearsalDraft(undefined),
    setMemoryEnabled: (enabled) => setProfile((current) => ({ ...current, memorySettings: { enabled, saveMistakes: enabled, savePreferences: enabled, saveAudio: current.memorySettings?.saveAudio ?? false }, memoryNotes: enabled ? current.memoryNotes : [], recommendationHistory: enabled ? current.recommendationHistory : [] })),
    clearMemory: () => setProfile((current) => ({ ...current, memoryNotes: [], recommendationHistory: [] })),
    recordRecommendationChoice: (scenarioId) => setProfile((current) => { if (current.memorySettings?.enabled === false || !scenarioId) return current; const history = [scenarioId, ...(current.recommendationHistory ?? []).filter((id) => id !== scenarioId)].slice(0, 5); return { ...current, recommendationHistory: history }; }),
    clearRecommendationHistory: () => setProfile((current) => ({ ...current, recommendationHistory: [] })),
    removeRecommendationChoice: (scenarioId) => setProfile((current) => ({ ...current, recommendationHistory: (current.recommendationHistory ?? []).filter((id) => id !== scenarioId) })),
    restoreRecommendationChoice: (scenarioId) => setProfile((current) => { if (current.memorySettings?.enabled === false || !scenarioId) return current; return { ...current, recommendationHistory: [scenarioId, ...(current.recommendationHistory ?? []).filter((id) => id !== scenarioId)].slice(0, 5) }; }),
    recordRecommendationStarted: (scenarioId) => setProfile((current) => current.memorySettings?.enabled === false ? current : ({ ...current, recommendationOutcomes: updateRecommendationOutcome(current.recommendationOutcomes ?? {}, scenarioId, "started", new Date().toISOString()) })),
    recordRecommendationCompleted: (scenarioId) => setProfile((current) => current.memorySettings?.enabled === false ? current : ({ ...current, recommendationOutcomes: updateRecommendationOutcome(current.recommendationOutcomes ?? {}, scenarioId, "completed", new Date().toISOString()) })),
  }), [profile, scenarioData, sessionData, evaluationData, rehearsalDraft, hasHydrated]);

  return <AppContext.Provider value={value}>{children}</AppContext.Provider>;
}

export function useApp() {
  const context = useContext(AppContext);
  if (!context) throw new Error("useApp must be used within AppProvider");
  return context;
}
