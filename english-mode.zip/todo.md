
# Project TODO

- [x] AI-native domain models for tutor profiles, turns, memory, scenarios, sessions, evaluations, skills, and entitlements
- [x] Provider-independent AI gateway with mock chat, scenario generation, and evaluation
- [x] Mock speech-to-text provider with realistic fixtures and error states
- [ ] Privacy scrubber, safe JSON parsing, retry policy, budget guard, idempotency, and circuit-breaker utilities
- [ ] Persistent learning memory and adaptive difficulty loop
- [x] Premium ENGLISH MODE design system and reusable mobile components
- [x] Onboarding flow for goal, level, interests, and practice duration
- [x] Five-tab navigation: Home, Practice, Progress, Time Machine, Profile
- [x] Home dashboard with Power Score, daily challenge, focus skill, and streak
- [x] Practice hub, scenario lists, custom scenario input, and scenario detail
- [x] Live speaking rehearsal with transcript, microphone state, progress, and safe exit
- [x] Evaluation screen with performance scores, corrections, and next challenge
- [x] Progress dashboard with skill trends and recent sessions
- [x] Time Machine comparison flow for then/now speaking improvement
- [x] Profile, settings, privacy, and subscription entry points
- [ ] Accessibility labels, responsive portrait layouts, and reduced-motion support
- [x] Unit tests, type checks, linting, and end-to-end navigation verification
- [x] Generate branded ENGLISH MODE launcher icon and update app configuration
- [x] Add reusable educational types for lessons, activities, objectives, mastery, and review items
- [x] Add adaptive curriculum utilities for mastery updates, review scheduling, diagnostic scoring, and remediation
- [x] Add a lightweight educational practice surface with flashcards, feedback, and review actions
- [x] Add permission-aware voice service contracts for recording, transcription, playback, and pronunciation analysis
- [x] Add voice error states, captions, recording duration, and no-audio-retention-by-default behavior
- [x] Add monetization domain types, plan definitions, entitlements, and free-tier usage limits
- [x] Add mock billing provider with purchase and restore flows
- [x] Add entitlement-aware paywall states and resilient upgrade messaging
- [x] Add teaching modes, objectives, guided practice, hints, transfer tasks, and formative feedback utilities
- [ ] Add teaching-aware lesson recovery and confidence support states
- [x] Add explainable AI orchestration contracts for teacher, evaluator, planner, memory, retrieval, safety, and model routing
- [ ] Add memory confidence gates, context trimming, local retrieval ranking, and safe fallback behavior

## Improvement pass

- [x] Replace placeholder voice behavior with a provider-aware voice session hook and explicit permission/error states
- [ ] Persist learner memory and completed session insights for adaptive recommendations
- [x] Make completed rehearsals update progress and recent session history
- [x] Add a real educational lesson entry point from Practice with a clearer guided flow
- [x] Improve accessibility labels, button semantics, and responsive spacing across core screens
- [x] Add tests for persistence-safe reducers, voice state transitions, and recommendation logic
- [x] Add typed AI task routing, provider contracts, budget guard, retries, idempotency, and circuit breaker utilities
- [x] Add prompt-injection sanitization, AI error mapping, context compression, and safe fallback messaging
- [x] Add learner memory consent model and memory-aware prompt construction

## Improvement pass 2

- [x] Add consent-aware persisted learner memory with clear/reset behavior
- [x] Add native-ready audio playback and provider lifecycle boundaries
- [x] Persist recoverable rehearsal state and restore unfinished sessions safely
- [x] Add richer post-session recommendations and lesson recovery affordances
- [x] Expand deterministic tests for memory consent, recovery, and audio state

## Improvement pass 3

- [ ] Add native-ready audio playback service contract with cleanup and safe no-op fallback
- [ ] Add learner memory review and clear-all controls in Profile
- [ ] Add richer session completion summary and explicit progress handoff
- [ ] Expand automated coverage for entitlement, recovery, and memory controls

## Motion improvement pass

- [x] Add centralized motion tokens and reduced-motion preference handling
- [x] Add reusable fade and slide entrance components with cleanup
- [x] Apply purposeful motion to lesson feedback, practice cards, and voice states
- [x] Add deterministic tests for reduced-motion and animation configuration

## Motion improvement pass 2

- [x] Add animated lesson feedback and voice processing state transitions
- [x] Add reduced-motion configuration tests and recovery assertions
- [x] Improve visible retry and offline fallback feedback on voice rehearsal

## Focused quality pass

- [x] Add reusable animated voice-status indicator with reduced-motion fallback
- [x] Add deterministic tests for motion tokens and recovery messaging
- [x] Re-run type checks and core tests under the current runtime conditions

## Functionality and mock-reduction pass

- [x] Add explicit environment configuration and a production mock-mode release guard
- [x] Add typed API client and repository contracts for profiles, scenarios, lessons, sessions, progress, and entitlements
- [x] Add honest loading, empty, offline, retry, and development-fallback state models
- [x] Add deterministic tests proving production cannot silently use mock data

## Data-layer integration pass

- [x] Add explicit remote-versus-development source selection for app data
- [x] Add typed profile, scenario, and dashboard data hooks with query status
- [x] Wire Home and Practice to loading, retry, offline, and fallback states
- [x] Add tests for source selection and query failure behavior

## Dashboard data integration pass

- [x] Add a typed dashboard data contract for score, focus skill, daily mission, and streak
- [x] Add a source-aware dashboard hook with loading, retry, and development fallback states
- [x] Wire Home to dashboard data while preserving the existing learner context fallback
- [x] Add deterministic dashboard source-selection tests

## Reliability improvement pass

- [x] Add network reachability state and offline-aware refresh behavior
- [x] Preserve last-known dashboard data during transient remote failures
- [x] Add clear dashboard skeleton and empty-state presentation
- [x] Add deterministic tests for offline and safe-refresh decisions

## Error handling pass

- [x] Add normalized app error types and user-safe error messages
- [x] Add API timeout, abort, and response-parse handling
- [x] Add source-hook last-known-data and retry failure safeguards
- [x] Add a root error boundary with recoverable reset behavior
- [x] Expand deterministic tests for API and persistence failures

## Error and monetization v2 pass

- [x] Add normalized application error codes and user-safe messages across API, voice, AI, and billing
- [x] Add API timeout, abort, and invalid-response handling
- [x] Add recoverable root error boundary and safe reset behavior
- [x] Add production billing service contract, product catalog, trial helpers, entitlement checks, usage limits, and sync boundaries
- [x] Add resilient purchase and restore states with retry messaging
- [x] Add deterministic tests for billing and error normalization

## Error-hardening pass 2

- [x] Add request cancellation and stale-response protection to data hooks
- [x] Normalize retryable versus terminal failures in user-facing status components
- [ ] Remove remaining deprecated runtime props and investigate warning sources
- [x] Add deterministic tests for cancellation, stale responses, and retry classification

## Error-hardening pass 3

- [ ] Trace and remove app-owned deprecated runtime props
- [x] Propagate cancellation signals into API and repository calls
- [x] Add cleanup-safe provider and persistence operations
- [x] Improve terminal-error versus retryable-error actions in visible UI
- [x] Add deterministic tests for cancellation and cleanup behavior

## Error-hardening pass 4

- [x] Add safe persistence wrappers with recoverable storage errors
- [x] Add voice-session cleanup and terminal-state safeguards
- [x] Add billing purchase and restore error normalization
- [x] Add diagnostic IDs and clearer retry guidance
- [x] Add deterministic tests for storage, voice, and billing failures

## Error-hardening pass 5

- [x] Add safe diagnostic IDs without exposing sensitive request data
- [x] Add navigation-safe handling for missing or malformed route parameters
- [x] Add stronger voice terminal-state recovery and retry messaging
- [x] Add deterministic tests for diagnostic and route-validation helpers

## Error-hardening pass 6

- [x] Show a non-sensitive diagnostic ID on the root recovery screen
- [x] Add copyable diagnostic support without exposing raw errors
- [x] Add API response-shape validation before screen state updates
- [x] Add deterministic tests for diagnostics and response validation

## Error-hardening pass 7

- [x] Add safe diagnostic copy action with clipboard failure fallback
- [x] Add explicit abort error classification and cancellation helper coverage
- [x] Add stronger response-shape validation for dashboard and scenario payloads
- [x] Add deterministic tests for clipboard-safe diagnostics and abort handling

## Onboarding improvement pass

- [x] Add explicit onboarding step model and validation helpers
- [x] Improve goal, level, interests, and duration selection with clear progress feedback
- [x] Add back navigation, resume-safe draft persistence, and recoverable completion errors
- [x] Improve accessibility labels, selected states, and reduced-motion transitions
- [x] Add deterministic onboarding validation and persistence tests

## Motion improvement pass 3

- [x] Add reusable motion primitives for fade, slide, press, and progress transitions
- [x] Apply purposeful motion to onboarding step changes and selection feedback
- [x] Add dynamic dashboard and practice-card entrance/stagger states
- [x] Add animated progress and speaking-state feedback without excessive motion
- [x] Add deterministic reduced-motion and animation configuration tests

## Continued mobile quality pass

- [x] Audit the live rehearsal and evaluation flows for the highest-value remaining UX gap
- [x] Implement one cohesive mobile UX or reliability improvement
- [x] Add deterministic tests for the new behavior
- [x] Verify the updated flow in portrait layout and preserve reduced-motion behavior

## Coaching feedback improvement pass

- [x] Audit the evaluation screen and session-to-coaching handoff
- [x] Add dynamic evaluation reveals and a clearer next-practice action
- [x] Add deterministic coverage for evaluation presentation helpers
- [x] Verify the updated coaching flow in portrait layout

## Learner memory clarity pass

- [x] Audit Profile privacy controls and current learner-memory state
- [x] Add transparent memory summary and clear-all controls
- [x] Add deterministic coverage for memory-control behavior
- [x] Verify the updated privacy interaction in portrait layout

## Guided lesson improvement pass

- [x] Audit the lesson activity flow and current feedback states
- [x] Add clearer activity progress, feedback, and recovery interactions
- [x] Add deterministic coverage for lesson state helpers
- [x] Verify the lesson flow in portrait layout

## Lesson continuity improvement pass

- [x] Audit lesson continuity and existing persistence patterns
- [x] Implement safe guided-lesson draft persistence and resume UI
- [x] Add deterministic coverage for lesson draft normalization
- [x] Verify portrait resume behavior

## Lesson discovery improvement pass

- [x] Audit Practice entry points and lesson-draft discovery state
- [x] Add a visible resume card for unfinished lessons
- [x] Add an explicit start-over action with draft cleanup
- [x] Add deterministic coverage and verify portrait interaction states

## Lesson progress handoff pass

- [x] Audit lesson completion and progress contracts
- [x] Add guided-lesson completion records and recommendation updates
- [x] Add a completion summary with a clear next action
- [x] Add deterministic coverage and verify portrait completion behavior

## Lesson completion summary pass

- [x] Audit lesson completion routing and progress presentation
- [x] Add a dedicated completion summary with score and reflection
- [x] Add a direct next-practice action and progress handoff
- [x] Add deterministic coverage and verify portrait navigation behavior

## Skill recommendation improvement pass

- [x] Audit completion-summary and scenario-selection contracts
- [x] Add a skill-specific next-scenario recommendation
- [x] Route the recommendation directly into a targeted rehearsal
- [x] Add deterministic coverage and verify portrait behavior

## Follow-up choice improvement pass

- [x] Audit recommendation data and completion-summary layout
- [x] Add multiple targeted scenario choices
- [x] Add accessible choice navigation and direct rehearsal actions
- [x] Add deterministic coverage and verify portrait behavior

## Recommendation rationale improvement pass

- [x] Audit recommendation rationale data and completion-summary presentation
- [x] Add explicit rationale text for focus-skill recommendations
- [x] Improve accessible explanation of why each scenario is relevant
- [x] Add deterministic rationale coverage and verify portrait behavior

## Recommendation choice tracking pass

- [x] Audit recommendation selection flow and persisted learner state
- [x] Add privacy-aware recommendation choice tracking
- [x] Use recent choices to diversify future recommendations
- [x] Add deterministic coverage and verify portrait selection behavior

## Recommendation history privacy pass

- [x] Audit Profile privacy UI and recommendation-history state
- [x] Add a transparent recommendation-history summary
- [x] Add a clear recommendation-history action with confirmation
- [x] Add deterministic coverage and verify portrait privacy interactions

## Per-item recommendation history pass

- [x] Audit Profile recommendation-history presentation and state actions
- [x] Add per-item recommendation-history deletion
- [x] Preserve all other personalization when one choice is removed
- [x] Add deterministic coverage and verify portrait Profile interactions

## Safer recommendation deletion pass

- [x] Audit Profile deletion interactions and privacy messaging
- [x] Add per-item deletion confirmation
- [x] Add visible post-deletion feedback without exposing private content
- [x] Add deterministic coverage and verify portrait privacy interactions

## Undoable recommendation deletion pass

- [x] Audit Profile removal feedback and privacy messaging
- [x] Add an undo action for accidental individual removal
- [x] Keep undo bounded and privacy-safe
- [x] Add deterministic coverage and verify portrait privacy interactions

## Recommendation outcome tracking pass

- [x] Audit recommendation navigation and completion records
- [x] Add privacy-aware started and completed outcome tracking
- [x] Use completed outcomes to improve recommendation ranking
- [x] Add deterministic coverage and verify portrait recommendation behavior

## Recommendation outcome summary pass

- [x] Audit Profile outcome state and recommendation privacy copy
- [x] Add started and completed recommendation summary
- [x] Add accessible outcome status presentation
- [x] Add deterministic coverage and verify portrait Profile behavior

## Outcome-aware recommendation labels pass

- [x] Audit recommendation outcome data and card presentation
- [x] Add new, in-progress, and revisit labels
- [x] Show recent completed-result context where useful
- [x] Add deterministic coverage and verify portrait recommendation presentation

## Outcome-aware rationale pass

- [x] Audit recommendation status and rationale presentation
- [x] Add rationale copy for new, in-progress, and revisit states
- [x] Keep recommendation explanations concise and accessible
- [x] Add deterministic coverage and verify portrait completion behavior

## Recent recommendation highlight pass

- [x] Audit Profile outcome data and recent-result presentation
- [x] Add the most recently completed recommendation highlight
- [x] Keep the highlight privacy-aware and empty-state safe
- [x] Add deterministic coverage and verify portrait Profile behavior

## Actionable recent-result pass

- [x] Audit Profile recent-result presentation and scenario navigation
- [x] Add privacy-safe completion-date context
- [x] Add a direct revisit action for the latest completed scenario
- [x] Add deterministic coverage and verify portrait Profile behavior

## Recommendation score context pass

- [x] Audit completion outcome data and Profile recent-result contract
- [x] Add privacy-aware score context for the latest completed recommendation
- [x] Keep score presentation safe when no matching session exists
- [x] Add deterministic coverage and verify portrait Profile behavior

## Compact recent-result pass

- [x] Audit score derivation and recent-result display contracts
- [x] Add deterministic score clamping and missing-session coverage
- [x] Improve compact date-and-score recent-result presentation
- [x] Verify TypeScript, tests, and portrait Profile behavior

## Recommendation rhythm improvement pass

- [x] Add a privacy-aware weekly recommendation outcome trend helper
- [x] Surface a calm weekly outcome summary in Progress
- [x] Add deterministic coverage for week bucketing and empty states
- [x] Verify TypeScript, tests, and portrait Progress behavior

## Progress truthfulness improvement pass

- [x] Audit hardcoded score and focus-skill copy in Progress
- [x] Derive score context and focus guidance from learner data
- [x] Add deterministic coverage for score-context and focus presentation helpers
- [x] Verify TypeScript, tests, and portrait Progress behavior

## Home focus-routing improvement pass

- [x] Audit static focus copy and current practice navigation in Home
- [x] Make Home focus guidance reflect the learner's selected skill
- [x] Route the Home focus action into a matching practice scenario
- [x] Add deterministic coverage and verify TypeScript, tests, and portrait Home behavior

## Home mission-routing improvement pass

- [x] Audit daily-mission copy and route consistency in Home
- [x] Route the daily mission using its live scenario ID
- [x] Add a safe Practice fallback when the mission ID is unavailable
- [x] Add deterministic coverage and verify TypeScript, tests, and portrait Home behavior

## Live rehearsal clarity improvement pass

- [x] Audit response-progress and microphone-state copy in rehearsal
- [x] Make visual progress and accessibility progress use the same response count
- [x] Add a clear permission and transcription recovery message
- [x] Add deterministic coverage and verify TypeScript, tests, and portrait rehearsal behavior

## Rehearsal reset-safety improvement pass

- [x] Audit reset behavior while permission and transcription work is in flight
- [x] Prevent reset from racing with active voice processing
- [x] Add clear disabled feedback for the reset action
- [x] Add deterministic coverage and verify TypeScript, tests, lint, and portrait rehearsal behavior

## Rehearsal response-limit improvement pass

- [x] Audit behavior after the maximum response count is reached
- [x] Prevent recording beyond the three-response practice objective
- [x] Add clear completion-state copy and accessibility state
- [x] Add deterministic coverage and verify TypeScript, tests, lint, and portrait rehearsal behavior

## Rehearsal reset-confirmation improvement pass

- [x] Audit reset copy and accidental-progress-loss behavior
- [x] Add confirmation before discarding a non-empty rehearsal
- [x] Keep empty reset actions immediate and clearly labeled
- [x] Add deterministic coverage and verify TypeScript, tests, lint, and portrait rehearsal behavior

## Post-rehearsal coaching handoff improvement pass

- [x] Audit evaluation summary and next-practice action
- [x] Add compact personalized action guidance based on the evaluation focus
- [x] Keep the primary coaching action direct and speaking-first
- [x] Add deterministic coverage and verify TypeScript, tests, lint, and portrait evaluation behavior

## Fresh-scenario coaching handoff improvement pass

- [x] Audit evaluation next-action routing for same-scenario repetition
- [x] Select a fresh scenario aligned to the next focus skill
- [x] Keep a safe current-scenario fallback when no fresh match exists
- [x] Add deterministic coverage and verify TypeScript, tests, lint, and portrait evaluation behavior

## Uploaded-material integration pass

- [x] Inspect all four uploaded text materials and identify actionable app requirements
- [x] Map the requirements to the existing ENGLISH MODE screens and domain models
- [x] Integrate the highest-value compatible content or behavior
- [x] Add deterministic coverage and verify TypeScript, tests, lint, and affected portrait flows

## Local speaking-signal improvement pass

- [x] Audit transcript-to-evaluation data flow for local speaking signals
- [x] Add privacy-safe filler detection without persisting raw audio
- [x] Surface concise filler coaching when the signal is present
- [x] Add deterministic coverage and verify TypeScript, tests, lint, and portrait evaluation behavior

## Newest uploaded-material integration pass

- [x] Inspect the newest uploaded material and identify one compatible requirement
- [x] Map the requirement to the existing ENGLISH MODE architecture
- [x] Integrate the selected capability without weakening privacy or speaking-first behavior
- [x] Add deterministic coverage and verify TypeScript, tests, lint, and affected portrait flows

## Local grammar-signal improvement pass

- [x] Audit which grammar rules can run locally without backend credentials
- [x] Add bounded article and collocation signal detection
- [x] Surface concise repair guidance without passing raw transcript text
- [x] Add deterministic coverage and verify TypeScript, tests, lint, and portrait evaluation behavior

## Local grammar coach v2 improvement pass

- [x] Audit the current grammar signal contract and transcript handoff
- [x] Add bounded tense and subject–verb agreement signals
- [x] Keep route serialization restricted to supported signal data
- [x] Add deterministic coverage and verify TypeScript, tests, lint, and portrait Evaluation behavior

## Coaching-signal preference improvement pass

- [x] Audit Profile settings and the evaluation signal handoff
- [x] Add persisted preferences for filler and grammar coaching
- [x] Filter transient coaching signals according to learner preferences
- [x] Add deterministic coverage and verify Profile, rehearsal, and Evaluation flows

## Coaching preference reset improvement pass

- [x] Audit the current coaching preference state and Profile controls
- [x] Add a confirmed reset-to-default coaching preference action
- [x] Keep reset behavior independent from learner memory and progress
- [x] Add deterministic coverage and verify TypeScript, tests, lint, and portrait Profile behavior

## Continued quality improvement pass

- [x] Audit remaining user-facing warnings and the highest-value mobile UX gap
- [x] Implement one focused reliability or accessibility improvement
- [x] Add deterministic coverage and re-run TypeScript, tests, and lint
- [x] Verify the updated flow in portrait layout and save a checkpoint

- [x] Preserve completed-answer score state when a guided lesson is resumed
- [x] Prevent malformed persisted score values from affecting completion results

## Resumable lesson clarity improvement pass

- [x] Show meaningful completed-answer progress in the resume banner
- [x] Add a confirmed start-over action that clears only the unfinished lesson draft
- [x] Add deterministic coverage for resume copy and draft reset behavior
- [x] Verify the updated lesson flow in portrait layout and save a checkpoint


## Error handling and mock fallback improvement pass

- [x] Audit current runtime warnings, data-source selection, and failure states
- [x] Add explicit development-only mock-data fallback with truthful source labeling
- [x] Strengthen user-safe error handling and retry behavior without masking production failures
- [x] Add deterministic coverage and re-run TypeScript, tests, lint, and affected flow verification
- [x] Save a stable checkpoint after validation


## Error resilience follow-up pass

- [x] Audit remaining runtime warnings, retry behavior, and data-source edge cases
- [x] Add resilient last-known-data or development fallback behavior without masking production failures
- [x] Improve user-safe failure recovery and source labeling
- [x] Add deterministic regression coverage and validate the affected flows
- [x] Save a stable checkpoint after validation

