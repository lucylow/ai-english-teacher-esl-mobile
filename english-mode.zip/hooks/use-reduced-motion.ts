import { AccessibilityInfo } from "react-native";
import { useEffect, useState } from "react";

export function useReducedMotion() { const [reduced, setReduced] = useState(false); useEffect(() => { let mounted = true; AccessibilityInfo.isReduceMotionEnabled().then((value) => { if (mounted) setReduced(value); }); const subscription = AccessibilityInfo.addEventListener("reduceMotionChanged", setReduced); return () => { mounted = false; subscription.remove(); }; }, []); return reduced; }
