import { useCallback, useEffect, useRef, useState } from "react";
import { MockSpeechToTextProvider, requestMicrophonePermission, type VoiceState } from "@/src/voice";
import { isCurrentVoiceOperation, nextVoiceOperation } from "@/src/voice-session-safety";

export function useVoiceSession(initial?: { transcript?: string[]; elapsed?: number }) {
  const provider = useRef(new MockSpeechToTextProvider()).current;
  const operationRef = useRef(0);
  const [state, setState] = useState<VoiceState>("idle");
  const [elapsed, setElapsed] = useState(initial?.elapsed ?? 0);
  const [transcript, setTranscript] = useState<string[]>(initial?.transcript ?? []);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (state !== "recording") return;
    const timer = setInterval(() => setElapsed((value) => value + 1), 1000);
    return () => clearInterval(timer);
  }, [state]);

  const start = useCallback(async () => {
    const operation = nextVoiceOperation(operationRef.current);
    operationRef.current = operation;
    setError(null);
    setState("permission");
    try {
      const granted = await requestMicrophonePermission();
      if (!isCurrentVoiceOperation(operation, operationRef.current)) return;
      if (!granted) throw new Error("MIC_PERMISSION_DENIED");
      await provider.start();
      if (!isCurrentVoiceOperation(operation, operationRef.current)) return;
      setState("recording");
    } catch (caught) {
      if (!isCurrentVoiceOperation(operation, operationRef.current)) return;
      setError(caught instanceof Error ? caught.message : "MICROPHONE_ERROR");
      setState("error");
    }
  }, [provider]);

  const stop = useCallback(async () => {
    if (state !== "recording") return;
    const operation = nextVoiceOperation(operationRef.current);
    operationRef.current = operation;
    setState("processing");
    try {
      const result = await provider.stop();
      if (!isCurrentVoiceOperation(operation, operationRef.current)) return;
      setTranscript((items) => [...items, result.text]);
      setState("idle");
    } catch (caught) {
      if (!isCurrentVoiceOperation(operation, operationRef.current)) return;
      setError(caught instanceof Error ? caught.message : "TRANSCRIPTION_ERROR");
      setState("error");
    }
  }, [provider, state]);

  const cancel = useCallback(async () => {
    operationRef.current = nextVoiceOperation(operationRef.current);
    await provider.cancel();
    setState("idle");
    setError(null);
  }, [provider]);

  const reset = useCallback(() => {
    operationRef.current = nextVoiceOperation(operationRef.current);
    void provider.cancel();
    setTranscript([]);
    setElapsed(0);
    setError(null);
    setState("idle");
  }, [provider]);

  return { state, elapsed, transcript, error, isRecording: state === "recording", isProcessing: state === "processing" || state === "permission", start, stop, cancel, reset };
}
