import { useEffect, useRef } from "react";
import { Animated, StyleSheet, View } from "react-native";

import { useReducedMotion } from "@/hooks/use-reduced-motion";
import { motion } from "@/src/motion";
import { palette } from "@/src/ui";

export function AnimatedProgressBar({ value, color = palette.coral, delay = 0 }: { value: number; color?: string; delay?: number }) {
  const reduced = useReducedMotion();
  const progress = useRef(new Animated.Value(reduced ? clamp(value) : 0)).current;

  useEffect(() => {
    const target = clamp(value);
    progress.stopAnimation();
    if (reduced) {
      progress.setValue(target);
      return;
    }
    const animation = Animated.timing(progress, { toValue: target, duration: motion.standard + 80, delay, easing: motion.ease, useNativeDriver: false });
    animation.start();
    return () => { animation.stop(); progress.stopAnimation(); };
  }, [delay, progress, reduced, value]);

  const width = progress.interpolate({ inputRange: [0, 100], outputRange: ["0%", "100%"] });
  return <View accessible accessibilityLabel={`${Math.round(value)} percent`} style={styles.track}><Animated.View style={[styles.fill, { width, backgroundColor: color }]} /></View>;
}

function clamp(value: number) { return Math.max(0, Math.min(100, value)); }

const styles = StyleSheet.create({ track: { height: 8, borderRadius: 8, backgroundColor: "#E9E4DC", overflow: "hidden" }, fill: { height: 8, borderRadius: 8 } });
