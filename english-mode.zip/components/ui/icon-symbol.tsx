import MaterialIcons from "@expo/vector-icons/MaterialIcons";
import { ComponentProps } from "react";
import { OpaqueColorValue, type StyleProp, type TextStyle } from "react-native";

type IconName = ComponentProps<typeof MaterialIcons>["name"];
const MAPPING: Record<string, IconName> = {
  "house.fill": "home", "mic.fill": "mic", "chart.bar.fill": "bar-chart", "clock.fill": "history", "person.fill": "person", "chevron.right": "chevron-right", "chevron.left": "chevron-left", "sparkles": "auto-awesome", "flame.fill": "local-fire-department", "play.fill": "play-arrow", "lock.fill": "lock", "checkmark.circle.fill": "check-circle", "arrow.up.right": "north-east", "gearshape.fill": "settings", "shield.fill": "shield", "waveform": "graphic-eq", "info.circle": "info-outline"
};
export function IconSymbol({ name, size = 24, color, style }: { name: keyof typeof MAPPING | string; size?: number; color: string | OpaqueColorValue; style?: StyleProp<TextStyle>; weight?: string }) { return <MaterialIcons color={color} size={size} name={MAPPING[name] ?? "help-outline"} style={style} />; }
