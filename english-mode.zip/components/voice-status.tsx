import { useEffect, useRef } from "react";
import { Animated, StyleSheet, Text, View } from "react-native";
import { palette } from "@/src/ui";
import { useReducedMotion } from "@/hooks/use-reduced-motion";
import { voiceStatusLabel } from "@/src/rehearsal";

export function VoiceStatus({ active, processing, error }: { active: boolean; processing: boolean; error?: string | null }) { const reduced = useReducedMotion(); const pulse = useRef(new Animated.Value(0.55)).current; useEffect(() => { pulse.stopAnimation(); if (reduced || !active) { pulse.setValue(active ? 0.75 : 0.55); return; } const loop = Animated.loop(Animated.sequence([Animated.timing(pulse, { toValue: 1, duration: 650, useNativeDriver: true }), Animated.timing(pulse, { toValue: 0.55, duration: 650, useNativeDriver: true })])); loop.start(); return () => { loop.stop(); pulse.stopAnimation(); }; }, [active, reduced, pulse]); const label = voiceStatusLabel({ error, isProcessing: processing, listening: active }); return <View accessible accessibilityLiveRegion="polite" accessibilityLabel={label} style={styles.wrap}><Animated.View style={[styles.dot, { opacity: pulse }, active && styles.activeDot, error && styles.errorDot]} /><Text style={[styles.label, error && styles.errorText]}>{label}</Text></View>; }

const styles = StyleSheet.create({ wrap: { flexDirection: "row", alignItems: "center", gap: 7, marginTop: 4 }, dot: { width: 7, height: 7, borderRadius: 4, backgroundColor: palette.slate }, activeDot: { backgroundColor: palette.sage }, errorDot: { backgroundColor: palette.error }, label: { color: palette.sage, fontSize: 13 }, errorText: { color: "#F4A19A" } });
