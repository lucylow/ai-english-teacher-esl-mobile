import { useEffect, useRef } from "react";
import { Animated, type ViewProps } from "react-native";
import { motion } from "@/src/motion";
import { useReducedMotion } from "@/hooks/use-reduced-motion";

export function AnimatedEntrance({ children, delay = 0, style, ...props }: ViewProps & { delay?: number }) { const reduced = useReducedMotion(); const value = useRef(new Animated.Value(reduced ? 1 : 0)).current; useEffect(() => { value.stopAnimation(); if (reduced) { value.setValue(1); return; } value.setValue(0); const animation = Animated.timing(value, { toValue: 1, duration: motion.entrance, delay, easing: motion.ease, useNativeDriver: true }); animation.start(); return () => { animation.stop(); value.stopAnimation(); }; }, [delay, reduced, value]); const translateY = value.interpolate({ inputRange: [0, 1], outputRange: [12, 0] }); return <Animated.View {...props} style={[style, { opacity: value, transform: [{ translateY }] }]}>{children}</Animated.View>; }
