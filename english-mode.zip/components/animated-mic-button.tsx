import { useEffect, useRef } from "react";
import { Animated, Pressable, StyleSheet, Text } from "react-native";

import { useReducedMotion } from "@/hooks/use-reduced-motion";
import { motion } from "@/src/motion";
import { palette } from "@/src/ui";

export function AnimatedMicButton({ active, processing, disabled, completed = false, onPress }: { active: boolean; processing: boolean; disabled?: boolean; completed?: boolean; onPress: () => void }) {
  const reduced = useReducedMotion();
  const pulse = useRef(new Animated.Value(1)).current;

  useEffect(() => {
    pulse.stopAnimation();
    if (reduced || !active || processing) {
      pulse.setValue(1);
      return;
    }
    const loop = Animated.loop(Animated.sequence([
      Animated.timing(pulse, { toValue: 1.06, duration: motion.standard, useNativeDriver: true }),
      Animated.timing(pulse, { toValue: 1, duration: motion.standard, useNativeDriver: true }),
    ]));
    loop.start();
    return () => { loop.stop(); pulse.stopAnimation(); };
  }, [active, processing, pulse, reduced]);

  return <Animated.View style={{ transform: [{ scale: pulse }] }}><Pressable disabled={disabled} accessibilityRole="button" accessibilityLabel={completed ? "Response objective complete" : processing ? "Processing response" : active ? "Stop recording" : "Start recording"} accessibilityState={{ busy: processing, disabled }} onPress={onPress} style={({ pressed }) => [styles.button, active && styles.active, processing && styles.processing, completed && styles.completed, disabled && styles.disabled, pressed && styles.pressed]}><Text style={styles.icon}>{processing ? "…" : completed ? "✓" : active ? "■" : "●"}</Text></Pressable></Animated.View>;
}

const styles = StyleSheet.create({ button: { width: 82, height: 82, borderRadius: 41, backgroundColor: palette.coral, alignItems: "center", justifyContent: "center", borderWidth: 7, borderColor: "#4C3435" }, active: { backgroundColor: palette.sage }, processing: { backgroundColor: "#6D747B" }, completed: { backgroundColor: palette.sage }, disabled: { opacity: 0.6 }, pressed: { opacity: 0.78, transform: [{ scale: 0.96 }] }, icon: { color: "#FFFFFF", fontSize: 26 }, });
